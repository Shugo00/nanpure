# 使用部品・出典

- Python 3.12：PSF License．Windows版にランタイムを同梱する．
- pygame-ce 2.5.8（Windows），2.5.7（今回のWeb実測）：LGPL-2.1-or-later．https://github.com/pygame-community/pygame-ce
- SDL等：pygame-ce配布物に含まれるライセンス表示を保持する．
- Noto Sans CJK JP Regular Sans2.004：SIL Open Font License 1.1．`src/nanpure/assets/OFL-NotoSansCJK.txt`と`font-manifest.json`を参照．フォント未改変．
- pygbag 0.9.3：MIT．https://github.com/pygame-web/pygbag ，Webランタイム：https://pygame-web.github.io/ ．ブラウザ版は初回にCDNから実行環境を取得する．オフライン起動を保証しない．
- PyInstaller 6.22.3：GPL-2.0-or-later with Bootloader Exception．ビルド用．https://pyinstaller.org/

共通固定参考資産`minesweeper-reference/0.1.0-rc2-r1`からフォント・ライセンス・出典manifestを固定コピーした．Webテンプレートとビルド／検証の進め方はマインスイーパーの既存実装を参照して本ゲーム用へ調整した．保存・計時・盤面・解法処理はナンプレ用の新規実装であり，元ゲームのルールは含まない．元ゲーム側のファイルは変更していない．

依存パッケージは同じPython3.12.14の既存ローカル環境から本ゲーム専用venvへコピーして初期検証した．ネットワーク経由の再取得が成功したとは扱わない．配布物では取得済みのパッケージ内ライセンスを`third_party/`へ同梱する．
