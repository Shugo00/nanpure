"""Physical cells and all-different constraints; no GUI dependency."""
from dataclasses import dataclass
from functools import lru_cache
import json
from pathlib import Path


@dataclass(frozen=True)
class Topology:
    key: str
    name: str
    n: int
    box: int
    coords: tuple
    units: tuple
    peers: tuple
    memberships: tuple
    boards: tuple
    origins: tuple
    height: int
    width: int

    @property
    def count(self):
        return len(self.boards)

    @property
    def full(self):
        return (1 << self.n) - 1

    @property
    def form(self):
        return "standard" if self.key == "standard" else "large" if self.key == "large" else "composite"

    def index(self):
        return {p: i for i, p in enumerate(self.coords)}

    def complete_valid(self, values):
        return (len(values) == len(self.coords)
                and all(type(v) is int and 1 <= v <= self.n for v in values)
                and all(len({values[i] for i in u}) == self.n for u in self.units))

    def check_values(self, values):
        if len(values) != len(self.coords) or any(type(v) is not int or not 0 <= v <= self.n for v in values):
            raise ValueError("盤面の数字・長さが不正")


def make_topology(key, name, n, origins):
    box = {9: 3, 16: 4}[n]
    origins = tuple(tuple(p) for p in origins)
    coords = tuple(sorted({(r + y, c + x) for r, c in origins for y in range(n) for x in range(n)}))
    lookup = {p: i for i, p in enumerate(coords)}
    boards, groups = [], []
    for r, c in origins:
        board = tuple(lookup[r + y, c + x] for y in range(n) for x in range(n))
        boards.append(board)
        groups.extend(tuple(board[y*n+x] for x in range(n)) for y in range(n))
        groups.extend(tuple(board[y*n+x] for y in range(n)) for x in range(n))
        groups.extend(tuple(board[(by+y)*n+bx+x] for y in range(box) for x in range(box))
                      for by in range(0, n, box) for bx in range(0, n, box))
    units = tuple(dict.fromkeys(tuple(sorted(u)) for u in groups))
    memberships = tuple(tuple(j for j, u in enumerate(units) if i in u) for i in range(len(coords)))
    peers = tuple(tuple(sorted(set().union(*(set(units[j]) for j in membership)) - {i}))
                  for i, membership in enumerate(memberships))
    return Topology(key, name, n, box, coords, units, peers, memberships, tuple(boards), origins,
                    max(y for y, x in coords)+1, max(x for y, x in coords)+1)


@lru_cache(maxsize=1)
def all_topologies():
    source = Path(__file__).with_name("layouts.json")
    data = json.loads(source.read_text(encoding="utf-8"))
    result = {"standard": make_topology("standard", "標準 9×9", 9, [(0, 0)]),
              "large": make_topology("large", "16×16", 16, [(0, 0)])}
    for row in data["layouts"]:
        result[row["id"]] = make_topology(row["id"], row["name"], 9, row["origins"])
    return result


def get_topology(key):
    return all_topologies()[key]
