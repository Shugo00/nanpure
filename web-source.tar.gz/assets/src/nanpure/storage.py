"""Versioned local state; failed writes never advance the saved generation."""
from contextlib import contextmanager
from copy import deepcopy
import json
import math
import os
from pathlib import Path
import tempfile
from .session import Session


class StorageError(RuntimeError):
    pass


class Conflict(StorageError):
    pass


def empty_state():
    return {"schema": 1, "revision": 0, "settings": {"auto_delete": True},
            "slots": {}, "records": [], "bests": {}, "seen": []}


def record_key(record):
    bounds = record["bounds"] if record["form"] == "composite" else []
    return json.dumps([record["mode"], record["form"], record["difficulty"], bounds], separators=(",", ":"))


def add_record(data, record):
    data["records"].append(deepcopy(record))
    data["records"] = data["records"][-1000:]
    key = record_key(record)
    if key not in data["bests"] or record["total"] < data["bests"][key]["total"]:
        data["bests"][key] = deepcopy(record)


def validate(data):
    try:
        if data["schema"] != 1 or type(data["schema"]) is not int:
            raise ValueError("未対応の保存形式")
        if type(data["revision"]) is not int or data["revision"] < 0:
            raise ValueError("保存版が不正")
        if type(data["settings"]["auto_delete"]) is not bool:
            raise ValueError("設定が不正")
        if not isinstance(data["slots"], dict) or not set(data["slots"]) <= {"standard", "large", "composite"}:
            raise ValueError("保存枠が不正")
        for key, saved in data["slots"].items():
            if Session.from_dict(saved).play.t.form != key:
                raise ValueError("保存形式の取り違え")
        if not isinstance(data["records"], list) or len(data["records"]) > 1000 or not isinstance(data["bests"], dict):
            raise ValueError("成績一覧が不正")
        for r in data["records"]+list(data["bests"].values()):
            if (r["mode"] not in ("attack", "normal") or r["form"] not in ("standard", "large", "composite")
                    or r["difficulty"] not in ("easy", "normal", "hard", "very_hard")
                    or not isinstance(r["bounds"], list) or len(r["bounds"]) != 2
                    or any(type(v) is not int for v in r["bounds"])
                    or not 2 <= r["bounds"][0] <= r["bounds"][1] <= 14
                    or not isinstance(r["times"], list)
                    or not isinstance(r["ids"], list) or not isinstance(r["boards"], list)
                    or len(r["times"]) != (3 if r["mode"] == "attack" else 1)
                    or len(r["ids"]) != len(r["times"]) or len(r["boards"]) != len(r["times"])
                    or any(not isinstance(v, str) or len(v) != 64 or any(c not in '0123456789abcdef' for c in v) for v in r["ids"])
                    or len(set(r["ids"])) != len(r["ids"])
                    or any(type(v) is not int or (not r["bounds"][0] <= v <= r["bounds"][1] if r["form"] == "composite" else v != 1) for v in r["boards"])
                    or type(r["hints"]) is not int or r["hints"] < 0
                    or (r["mode"] == "attack" and r["hints"] != 0)
                    or type(r["completed_at"]) not in (int, float) or not math.isfinite(r["completed_at"]) or r["completed_at"] < 0
                    or any(type(v) not in (int, float) or not math.isfinite(v) or v < 0 for v in r["times"])
                    or type(r["total"]) not in (int, float) or not math.isfinite(r["total"])
                    or abs(r["total"]-sum(r["times"])) > .001):
                raise ValueError("成績が不正")
            record_key(r)
        if any(k != record_key(r) for k, r in data["bests"].items()):
            raise ValueError("ベストの分類が不正")
        if not isinstance(data["seen"], list) or any(not isinstance(x, str) or len(x) != 64 for x in data["seen"]):
            raise ValueError("出題履歴が不正")
        return data
    except (KeyError, TypeError, ValueError, IndexError, AttributeError) as e:
        raise StorageError(f"保存データを読み取れない：{e}") from e


@contextmanager
def _lock(path):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("a+b") as f:
        if not f.tell():
            f.write(b"0")
            f.flush()
        f.seek(0)
        try:
            if os.name == "nt":
                import msvcrt
                msvcrt.locking(f.fileno(), msvcrt.LK_NBLCK, 1)
            else:
                import fcntl
                fcntl.flock(f.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
        except OSError as e:
            raise Conflict("別の画面が保存中．再試行するか，片方を閉じて再読込みする") from e
        try:
            yield
        finally:
            f.seek(0)
            if os.name == "nt":
                msvcrt.locking(f.fileno(), msvcrt.LK_UNLCK, 1)
            else:
                fcntl.flock(f.fileno(), fcntl.LOCK_UN)


def _atomic(path, data):
    temp = None
    try:
        with tempfile.NamedTemporaryFile("w", encoding="utf-8", dir=path.parent, delete=False, suffix=".tmp") as f:
            temp = Path(f.name)
            json.dump(data, f, ensure_ascii=False, separators=(",", ":"), allow_nan=False)
            f.flush()
            os.fsync(f.fileno())
        os.replace(temp, path)
    finally:
        if temp and temp.exists():
            temp.unlink()


class FileStore:
    def __init__(self, directory=None):
        self.directory = Path(directory) if directory else Path(os.environ.get("LOCALAPPDATA", str(Path.home())))/"ZatsuGames"/"Nanpure"
        self.path = self.directory/"state.json"
        self.backup = self.directory/"state.backup.json"

    def load(self):
        if not self.path.exists():
            return empty_state()
        try:
            return validate(json.loads(self.path.read_text(encoding="utf-8")))
        except (OSError, ValueError) as e:
            raise StorageError(f"保存データを読み取れない：{e}") from e

    def save(self, data, expected_revision):
        validate(data)
        with _lock(self.directory/"state.lock"):
            previous = self.load()
            if previous["revision"] != expected_revision:
                raise Conflict("他の画面で保存された．上書きを避けるため再読込みが必要")
            updated = deepcopy(data)
            updated["revision"] = expected_revision+1
            if self.path.exists():
                _atomic(self.backup, previous)
            _atomic(self.path, updated)
            return updated["revision"]


class SaveManager:
    """Synchronous desktop writes; async adapters use begin/complete/fail too."""
    def __init__(self, data, store=None):
        self.data = data
        self.store = store
        self.generation = 0
        self.saved_generation = 0
        self.inflight = None
        self.error = ""

    def changed(self):
        self.generation += 1

    @property
    def pending(self):
        return self.generation > self.saved_generation

    def begin(self):
        if self.inflight is not None or not self.pending:
            return None
        self.inflight = self.generation
        return deepcopy(self.data), self.data["revision"]

    def complete(self, revision):
        if self.inflight is None:
            raise StorageError("対応する保存要求がない")
        self.data["revision"] = revision
        self.saved_generation = self.inflight
        self.inflight = None
        self.error = ""

    def fail(self, error):
        self.inflight = None
        self.error = str(error)

    def flush(self):
        request = self.begin()
        if request is None:
            return
        try:
            self.complete(self.store.save(*request))
        except (OSError, StorageError) as e:
            self.fail(e)
