import json
from pathlib import Path
from .lesson_copy import worked_explanation
from .reasoning import Step
from .topology import get_topology

TOPICS = {
    "candidates": "入れそうな数字をメモする",
    "naked_single": "候補が1つのマス",
    "hidden_single": "置き場所が1つの数字",
    "locked": "一列に並ぶ候補",
    "naked_pair": "同じ2つの候補を探す",
    "hidden_pair": "置き場所が同じ数字を探す",
    "xwing": "四隅を使うX-Wing",
    "trial": "数字を仮に置いてみる",
    "nested_trial": "仮置きの先でもう一度試す",
}

_PRACTICE = {
    "candidates": "金枠のマスと同じ横一列・縦一列・3×3の枠を見てください．どこにも出てこない数字をすべて選び，「答え合わせ」を押します．",
    "naked_single": "金枠のマスの小さな数字を見てください．ここに入る数字はどれでしょう？",
    "hidden_single": "金枠のマスと同じ行・列・3×3の枠を見比べます．ほかに置き場所がない数字を選んでください．",
    "locked": "水色のマスで，同じ数字のメモを探してください．その数字はどの行・列・枠で使われますか？　金枠のマスから消せる候補を1つ選びます．",
    "naked_pair": "水色の2マスには同じ2つの候補が残っています．この2マスで使い切る数字は，金枠のマスにも入るでしょうか？　消せる候補を1つ選んでください．",
    "hidden_pair": "水色の2マスにしか置けない数字が2つあります．この2マスに入る数字を絞ったら，メモから消せる数字を1つ選んでください．",
    "xwing": "水色の四隅で同じ数字のメモを探してください．その数字が対角のどちらの組に入っても，金枠から消せる候補はどれでしょう？",
    "trial": "金枠のマスに，候補を1つ仮に置いて考えます．その先で数字を置けなくなるのは，どの候補を試したときでしょう？",
    "nested_trial": "金枠のマスに数字を仮置きし，先で再び迷ったら両方の候補を試すと考えてください．どちらでも行き詰まるなら，最初のマスからどの候補を消せるでしょう？",
}


class Lesson:
    def __init__(self, topic, index=0):
        data = json.loads(Path(__file__).with_name("lessons.json").read_text(encoding="utf-8"))
        self.topic, self.index = topic, index
        self.data = data["topics"][topic][index]
        self.step = Step(**self.data["step"]) if "step" in self.data else None
        self.selected = self.step.cells[0] if self.step else self.data["cell"]
        self.mask = 0
        self.feedback = ""
        self.solved = False
        self.example_text = worked_explanation(self, get_topology("standard")) if index == 0 else ""

    @property
    def clue_cells(self):
        if self.topic in ("locked", "naked_pair", "hidden_pair", "xwing"):
            return self.step.premises
        return ()

    @property
    def instruction(self):
        return _PRACTICE[self.topic]

    def answer(self, cell, digit, t):
        if self.topic == "candidates":
            self.mask ^= 1 << (digit-1)
            self.feedback = ""
            self.solved = False
            return False
        bit = 1 << (digit-1)
        ok = (any(cell == i and digit == v for i, v in self.step.placements)
              or any(cell == i and bit & mask for i, mask in self.step.removals))
        self.solved = bool(ok)
        if ok:
            self.feedback = "正解です．" + worked_explanation(self, t, cell, digit)
        elif cell not in self.step.cells:
            self.feedback = "答えるのは金枠のマスです．枠の中を選んでから，数字を押してください．"
        elif not (self.data["domains"][cell] & bit):
            self.feedback = f"このマスのメモに{digit}はありません．小さく書かれた数字から選んでください．"
        elif self.step.placements:
            self.feedback = f"もう一度，{digit}を置ける場所を盤面のメモで確かめてみてください．"
        else:
            self.feedback = f"この解き方では，{digit}はメモに残ります．金枠のほかの候補を見てみましょう．"
        return self.solved

    def check_candidates(self):
        self.solved = self.mask == self.data["mask"]
        if self.solved:
            self.feedback = "正解です．" + worked_explanation(self, get_topology("standard"))
        elif self.mask & ~self.data["mask"]:
            extra = self.mask & ~self.data["mask"]
            digit = (extra & -extra).bit_length()
            self.feedback = f"{digit}は同じ行・列・3×3の枠のどこかにあります．盤面で見つけたら，もう一度{digit}を押してメモから外してください．"
        else:
            self.feedback = "まだ選べる数字があります．1から順に，金枠と同じ行・列・3×3の枠にあるか探してみてください．"
        return self.solved
