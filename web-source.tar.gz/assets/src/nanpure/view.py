"""Coordinate transforms and gesture arbitration shared by screen layouts."""
from dataclasses import dataclass
from math import hypot


@dataclass
class View:
    width: int
    height: int
    viewport: tuple
    scale: float = 1.0
    x: float = 0.0
    y: float = 0.0

    def fit(self, bounds=None):
        r, c, h, w = bounds or (0, 0, self.height, self.width)
        vx, vy, vw, vh = self.viewport
        self.scale = min((vw-12)/w, (vh-12)/h)
        self.x = vx+(vw-w*self.scale)/2-c*self.scale
        self.y = vy+(vh-h*self.scale)/2-r*self.scale

    def screen(self, row, col):
        return self.x+col*self.scale, self.y+row*self.scale

    def world(self, pos):
        return (pos[1]-self.y)/self.scale, (pos[0]-self.x)/self.scale

    def zoom(self, factor, anchor):
        row, col = self.world(anchor)
        minimum = min(self.viewport[2]/self.width, self.viewport[3]/self.height)*.5
        self.scale = min(140.0, max(minimum, self.scale*factor))
        self.x, self.y = anchor[0]-col*self.scale, anchor[1]-row*self.scale
        self.clamp()

    def pan(self, dx, dy):
        self.x += dx
        self.y += dy
        self.clamp()

    def clamp(self):
        vx, vy, vw, vh = self.viewport
        self.x = min(vx+vw-20, max(vx+20-self.width*self.scale, self.x))
        self.y = min(vy+vh-20, max(vy+20-self.height*self.scale, self.y))

    def visible(self):
        vx, vy, vw, vh = self.viewport
        r0, c0 = self.world((vx, vy))
        r1, c1 = self.world((vx+vw, vy+vh))
        return max(0, r0), max(0, c0), min(self.height, r1), min(self.width, c1)


class TouchGesture:
    def __init__(self):
        self.fingers = {}
        self.origins = {}
        self.consumed = False

    def down(self, finger, point):
        if not self.fingers:
            self.consumed = False
        self.fingers[finger] = point
        self.origins[finger] = point
        if len(self.fingers) > 1:
            self.consumed = True

    def move(self, finger, point, view):
        if finger not in self.fingers:
            return
        old = self.fingers[finger]
        if len(self.fingers) == 2:
            other = next(p for key, p in self.fingers.items() if key != finger)
            distance0 = hypot(old[0]-other[0], old[1]-other[1])
            distance1 = hypot(point[0]-other[0], point[1]-other[1])
            center0 = ((old[0]+other[0])/2, (old[1]+other[1])/2)
            center1 = ((point[0]+other[0])/2, (point[1]+other[1])/2)
            if distance0 > 3:
                view.zoom(distance1/distance0, center0)
                view.pan(center1[0]-center0[0], center1[1]-center0[1])
            self.consumed = True
        else:
            origin = self.origins[finger]
            if hypot(point[0]-origin[0], point[1]-origin[1]) > 8:
                self.consumed = True
            if self.consumed:
                view.pan(point[0]-old[0], point[1]-old[1])
        self.fingers[finger] = point

    def up(self, finger):
        point = self.fingers.pop(finger, None)
        self.origins.pop(finger, None)
        return point if point is not None and not self.consumed and not self.fingers else None
