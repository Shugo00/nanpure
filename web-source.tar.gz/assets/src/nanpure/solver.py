"""Two independent constraint-search paths. Limits never imply uniqueness."""
from dataclasses import dataclass
from functools import lru_cache


class SearchLimit(RuntimeError):
    pass


@dataclass
class SearchResult:
    count: int
    solution: list | None
    nodes: int


def bits(mask):
    while mask:
        bit = mask & -mask
        yield bit
        mask ^= bit


def _propagate(t, domains):
    queue = [i for i, m in enumerate(domains) if m and not m & (m - 1)]
    done = set()
    while True:
        while queue:
            i = queue.pop()
            if i in done:
                continue
            done.add(i)
            bit = domains[i]
            for j in t.peers[i]:
                old = domains[j]
                if old & bit:
                    new = old & ~bit
                    if not new:
                        return False
                    domains[j] = new
                    if not new & (new - 1):
                        queue.append(j)
        for unit in t.units:
            once = twice = 0
            for i in unit:
                twice |= once & domains[i]
                once |= domains[i]
            if once != t.full:
                return False
            unique = once & ~twice
            for i in unit:
                hit = domains[i] & unique
                if hit and domains[i] != hit:
                    if hit & (hit - 1):
                        return False
                    domains[i] = hit
                    queue.append(i)
        if not queue:
            return True


def solve_count(t, values, limit=2, node_limit=200000, rng=None):
    t.check_values(values)
    if limit < 1:
        raise ValueError("limit must be positive")
    domains = [(1 << (v - 1)) if v else t.full for v in values]
    count = nodes = 0
    solution = None

    def visit(d):
        nonlocal count, nodes, solution
        nodes += 1
        if nodes > node_limit:
            raise SearchLimit("解探索の上限に達した")
        if not _propagate(t, d):
            return
        undecided = [(m.bit_count(), i) for i, m in enumerate(d) if m & (m - 1)]
        if not undecided:
            count += 1
            if solution is None:
                solution = [m.bit_length() for m in d]
            return
        smallest = min(v[0] for v in undecided)
        options = [i for n, i in undecided if n == smallest]
        i = rng.choice(options) if rng else options[0]
        choices = list(bits(d[i]))
        if rng:
            rng.shuffle(choices)
        for bit in choices:
            child = d.copy()
            child[i] = bit
            visit(child)
            if count >= limit:
                break

    visit(domains)
    return SearchResult(count, solution, nodes)


@lru_cache(maxsize=2)
def _exact_matrix(t):
    n=t.n
    columns=[0]*(len(t.coords)+len(t.units)*n)
    row_columns=[]
    row_masks=[]
    for i in range(len(t.coords)):
        for v in range(n):
            keys=(i,)+tuple(len(t.coords)+u*n+v for u in t.memberships[i])
            bit=1<<(i*n+v)
            mask=0
            for c in keys:
                columns[c]|=bit
                mask|=1<<c
            row_columns.append(keys)
            row_masks.append(mask)
    return columns,row_columns,row_masks

def exact_cover_count(t,values,limit=2,node_limit=200000):
    """Algorithm X with integer row sets; independent of domain propagation."""
    t.check_values(values)
    if limit<1:raise ValueError('limit must be positive')
    columns,row_columns,row_masks=_exact_matrix(t)
    active_rows=(1<<(len(values)*t.n))-1
    active_columns=(1<<len(columns))-1
    def cover(row,rows,cols):
        conflict=0
        for c in row_columns[row]:conflict|=columns[c]
        return rows & ~conflict,cols & ~row_masks[row]
    for i,v in enumerate(values):
        if v:
            row=i*t.n+v-1
            if not active_rows & (1<<row):return 0
            active_rows,active_columns=cover(row,active_rows,active_columns)
    stack=[(active_rows,active_columns)]
    found=nodes=0
    while stack:
        rows,cols=stack.pop()
        nodes+=1
        if nodes>node_limit:raise SearchLimit('independent search limit')
        if not cols:
            found+=1
            if found>=limit:return found
            continue
        remaining=cols
        best_count=t.n+1
        while remaining:
            bit=remaining & -remaining
            available=columns[bit.bit_length()-1] & rows
            size=available.bit_count()
            if size<best_count:
                best_count,choices=size,available
                if size<=1:break
            remaining^=bit
        options=[]
        while choices:
            bit=choices & -choices
            options.append(bit.bit_length()-1)
            choices^=bit
        for row in reversed(options):stack.append(cover(row,rows,cols))
    return found

