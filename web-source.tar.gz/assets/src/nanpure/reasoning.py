"""Deterministic, explainable deduction. Player notes are never premises."""
from collections import Counter
from dataclasses import dataclass, field
from itertools import combinations
from .solver import bits

VERSION = "r1"
NAMES = {"naked_single": "候補が1つ", "hidden_single": "数字の入る場所が1つ",
         "locked": "区画と行・列の候補の連動", "naked_pair": "裸のペア",
         "hidden_pair": "隠れたペア", "xwing": "X-Wing", "trial": "仮置きによる矛盾"}


@dataclass
class Step:
    technique: str
    cells: tuple
    placements: tuple = ()
    removals: tuple = ()  # (physical cell, bit mask)
    premises: tuple = ()
    units: tuple = ()
    proof: dict = field(default_factory=dict)

    def text(self, t, stage=2):
        def loc(i):
            r, c = t.coords[i]
            return f"全体の{r+1}行{c+1}列"
        where = "，".join(loc(i) for i in self.cells[:4])
        if stage == 0:
            return f"{where}に注目する．"
        name = NAMES[self.technique]
        if self.technique == "naked_single":
            reason = "関係する行・列・区画の数字を除くと，候補が1つだけ残る．"
        elif self.technique == "hidden_single":
            reason = "この単位内で，ある数字を置ける場所が1マスだけである．"
        elif self.technique == "locked":
            reason = "ある単位の候補が別の単位との交わりに限られるため，その外側から候補を除ける．"
        elif self.technique == "naked_pair":
            reason = "同じ単位の2マスが同じ2候補に限られるため，他のマスからその2候補を除ける．"
        elif self.technique == "hidden_pair":
            reason = "同じ単位の2つの数字の置き場が同じ2マスだけなので，その2マスの他の候補を除ける．"
        elif self.technique == "xwing":
            reason = "同じ数字の候補が2行（または2列）で同じ2列（または2行）に限られる．その外側から候補を除ける．"
        else:
            i, digit = self.proof['assumption']
            def failure(proof):
                if 'contradiction' in proof:
                    error = proof['contradiction']
                    if error['kind'] == 'empty_cell':
                        return loc(error['cell'])+'の候補がなくなる'
                    unit = t.units[error['unit']]
                    if error['kind'] == 'duplicate':
                        return loc(unit[0])+'を含む単位で数字が重複する'
                    missing = '・'.join(str(b.bit_length()) for b in bits(error['mask']))
                    return loc(unit[0])+'を含む単位で'+missing+'の置き場がなくなる'
                branches = proof['branches']
                return '／'.join(loc(b['cell'])+'='+str(b['digit'])+'の場合も'+failure(b['proof']) for b in branches)
            reason = f"{loc(i)}を{digit}と仮定すると，{failure(self.proof)}．したがってこの仮定を除ける．（最大深さ{self.proof['depth']}，推論{self.proof['steps']}手）"
        if stage == 1:
            return f"{name}：{reason}"
        action = "，".join(f"{loc(i)}に{v}" for i, v in self.placements)
        action += "，".join(f"{loc(i)}から{'・'.join(str(b.bit_length()) for b in bits(m))}を除く" for i, m in self.removals)
        return f"{name}：{reason} {action}．"


def candidates(t, values):
    t.check_values(values)
    return [0 if v else t.full & ~sum_mask(values[j] for j in t.peers[i]) for i, v in enumerate(values)]


def sum_mask(values):
    mask = 0
    for v in values:
        if v:
            mask |= 1 << (v-1)
    return mask


def contradiction(t, values, d):
    for i, v in enumerate(values):
        if not v and not d[i]:
            return {"kind": "empty_cell", "cell": i}
    for u, unit in enumerate(t.units):
        used = 0
        possible = 0
        for i in unit:
            if values[i]:
                b = 1 << (values[i]-1)
                if used & b:
                    return {"kind": "duplicate", "unit": u, "digit": values[i]}
                used |= b
            else:
                possible |= d[i]
        missing = t.full & ~(used | possible)
        if missing:
            return {"kind": "missing_digit", "unit": u, "mask": missing}
    return None


def apply(t, values, d, step):
    for i, v in step.placements:
        if values[i] or not d[i] & (1 << (v-1)):
            raise ValueError("適用できない配置")
        values[i], d[i] = v, 0
        for j in t.peers[i]:
            d[j] &= ~(1 << (v-1))
    for i, mask in step.removals:
        d[i] &= ~mask


def logical_step(t, values, d, advanced=True):
    for i, m in enumerate(d):
        if m and m.bit_count() == 1:
            return Step("naked_single", (i,), ((i, m.bit_length()),), premises=t.peers[i])
    positions = []
    for u, unit in enumerate(t.units):
        pos = {b: tuple(i for i in unit if d[i] & b) for b in bits(t.full & ~sum_mask(values[i] for i in unit))}
        positions.append(pos)
        for b, cells in pos.items():
            if len(cells) == 1:
                i = cells[0]
                return Step("hidden_single", (i,), ((i, b.bit_length()),), premises=unit, units=(u,))
    if not advanced:
        return None
    for u, pos in enumerate(positions):
        uset = set(t.units[u])
        for b, cells in pos.items():
            if len(cells) < 2:
                continue
            common = set(t.memberships[cells[0]])
            for i in cells[1:]:
                common.intersection_update(t.memberships[i])
            for other in sorted(common - {u}):
                rem = tuple((i, b) for i in t.units[other] if i not in uset and d[i] & b)
                if rem:
                    return Step("locked", tuple(i for i, m in rem), removals=rem, premises=cells, units=(u, other))
    for u, unit in enumerate(t.units):
        pairs = {}
        for i in unit:
            if d[i].bit_count() == 2:
                pairs.setdefault(d[i], []).append(i)
        for m, cells in pairs.items():
            if len(cells) == 2:
                rem = tuple((i, d[i] & m) for i in unit if i not in cells and d[i] & m)
                if rem:
                    return Step("naked_pair", tuple(i for i, m in rem), removals=rem, premises=tuple(cells), units=(u,))
        hidden = {}
        for b, cells in positions[u].items():
            if len(cells) == 2:
                hidden.setdefault(cells, []).append(b)
        for cells, digits in hidden.items():
            if len(digits) == 2:
                mask = digits[0] | digits[1]
                rem = tuple((i, d[i] & ~mask) for i in cells if d[i] & ~mask)
                if rem:
                    return Step("hidden_pair", cells, removals=rem, premises=cells, units=(u,))
    for board in t.boards:
        n = t.n
        for transpose in (False, True):
            def cell(r, c):
                return board[c*n+r] if transpose else board[r*n+c]
            for b in bits(t.full):
                matches = {}
                for r in range(n):
                    cols = tuple(c for c in range(n) if d[cell(r, c)] & b)
                    if len(cols) == 2:
                        matches.setdefault(cols, []).append(r)
                for cols, rows in matches.items():
                    if len(rows) == 2:
                        rem = tuple((cell(r, c), b) for r in range(n) if r not in rows for c in cols if d[cell(r, c)] & b)
                        if rem:
                            return Step("xwing", tuple(i for i, m in rem), removals=rem,
                                        premises=tuple(cell(r, c) for r in rows for c in cols))
    return None


def refute(t, values, d, depth, budget):
    """Return a verifiable contradiction tree, or None (unknown OR satisfiable)."""
    trace = []
    while True:
        budget[0] -= 1
        if budget[0] < 0:
            return None
        error = contradiction(t, values, d)
        if error:
            return {"trace": trace, "contradiction": error, "depth": 0, "steps": len(trace)}
        step = logical_step(t, values, d, advanced=False)
        if not step:
            break
        apply(t, values, d, step)
        trace.append([step.technique, list(step.placements)])
    remaining = [(m.bit_count(), i) for i, m in enumerate(d) if m]
    if not remaining or depth == 0:
        return None
    _, i = min(remaining)
    branches = []
    for b in bits(d[i]):
        vs, ds = values[:], d[:]
        apply(t, vs, ds, Step("trial", (i,), ((i, b.bit_length()),)))
        proof = refute(t, vs, ds, depth-1, budget)
        if proof is None:
            return None
        branches.append({"cell": i, "digit": b.bit_length(), "proof": proof})
    return {"trace": trace, "branches": branches, "depth": 1+max(b["proof"]["depth"] for b in branches),
            "steps": len(trace)+sum(1+b["proof"]["steps"] for b in branches)}


def trial_step(t, values, d, max_depth=3, budget_limit=6000):
    choices = sorted((m.bit_count(), i) for i, m in enumerate(d) if m)
    budget = [budget_limit]
    # Prefer short one-level contradictions before exploring nested hypotheses.
    for depth in range(1, max_depth+1):
        for _, i in choices[:12]:
            for b in bits(d[i]):
                vs, ds = values[:], d[:]
                apply(t, vs, ds, Step("trial", (i,), ((i, b.bit_length()),)))
                proof = refute(t, vs, ds, depth-1, budget)
                if proof is not None:
                    proof["depth"] += 1
                    proof["assumption"] = [i, b.bit_length()]
                    return Step("trial", (i,), removals=((i, b),), premises=(i,), proof=proof)
                if budget[0] < 0:
                    return None
    return None


def next_step(t, values, d=None, max_depth=3):
    d = candidates(t, values) if d is None else d
    if contradiction(t, values, d):
        return None
    return logical_step(t, values, d) or (trial_step(t, values, d, max_depth) if max_depth else None)


def evaluate(t, initial, max_depth=3, keep_trace=False):
    values = list(initial)
    d = candidates(t, values)
    counts = Counter()
    trace = []
    depth = branch_steps = trial_steps = 0
    while not all(values):
        step = next_step(t, values, d, max_depth)
        if step is None:
            return None
        apply(t, values, d, step)
        counts[step.technique] += 1
        if step.technique == "trial":
            depth = max(depth, step.proof["depth"])
            branch_steps = max(branch_steps, step.proof["steps"])
            trial_steps += step.proof["steps"]
        if keep_trace:
            trace.append(step)
    if not t.complete_valid(values):
        return None
    if depth > 1 or counts["trial"] > 3*t.count or branch_steps > 24:
        difficulty = "very_hard"
    elif counts["trial"] or counts["xwing"]:
        difficulty = "hard"
    elif any(counts[k] for k in ("locked", "naked_pair", "hidden_pair")):
        difficulty = "normal"
    else:
        difficulty = "easy"
    report = {"version": VERSION, "difficulty": difficulty, "counts": dict(counts), "depth": depth,
              "max_branch_steps": branch_steps, "trial_steps": trial_steps, "steps": sum(counts.values())}
    if keep_trace:
        report["trace"] = trace
    return report
