"""Session state and injectable clocks. Time attack cannot pause or resume."""
import time
from .play import Play


class Timer:
    def __init__(self, attack=False, monotonic=None, wall=None):
        self.clock = (wall or time.time) if attack else (monotonic or time.monotonic)
        self.attack = attack
        self.accumulated = 0.0
        self.started = None
        self.last = None
        self.valid = True

    def start(self):
        if self.started is None:
            self.started = self.last = self.clock()

    def elapsed(self):
        if self.started is None:
            return self.accumulated
        now = self.clock()
        if now < self.last:
            self.valid = False
        self.last = now
        return self.accumulated+max(0.0, now-self.started)

    def stop(self, at=None):
        self.accumulated = (self.accumulated+max(0.0, at-self.started)
                            if at is not None and self.started is not None else self.elapsed())
        self.started = self.last = None
        return self.accumulated


class Session:
    def __init__(self, puzzles, attack=False, bounds=(2, 14), monotonic=None, wall=None):
        if len(puzzles) != (3 if attack else 1):
            raise ValueError("通常1問・タイムアタック3問")
        if len({p.id for p in puzzles}) != len(puzzles):
            raise ValueError("出題が重複")
        if len({(p.difficulty, Play(p).t.form) for p in puzzles}) != 1:
            raise ValueError("形式・難易度の混在")
        self.puzzles = puzzles
        self.attack = attack
        self.bounds = tuple(bounds)
        self.index = 0
        self.play = Play(puzzles[0])
        self.timer = Timer(attack, monotonic, wall)
        self.state = "prepare"
        self.times = []
        self.record = None

    def ready(self):
        if self.state == "prepare":
            self.state = "playing"
            self.timer.start()

    def pause(self, at=None):
        if self.attack or self.state != "playing":
            return False
        self.timer.stop(at)
        self.state = "paused"
        return True

    def resume(self):
        if self.state == "paused" and not self.attack:
            self.timer.start()
            self.state = "playing"
            return True
        return False

    def hint(self):
        if self.attack or self.state != "playing":
            return None
        return self.play.hint()

    def finish_puzzle(self):
        if self.state != "playing" or not self.play.complete:
            return False
        self.times.append(self.timer.stop())
        if self.index+1 < len(self.puzzles):
            auto_delete = self.play.auto_delete
            self.index += 1
            self.play = Play(self.puzzles[self.index])
            self.play.auto_delete = auto_delete
            self.timer.accumulated = 0.0
            self.state = "prepare"
        else:
            self.state = "completed"
            if self.timer.valid:
                self.record = {"mode": "attack" if self.attack else "normal", "form": self.play.t.form,
                               "difficulty": self.play.puzzle.difficulty, "bounds": list(self.bounds),
                               "ids": [p.id for p in self.puzzles], "times": self.times[:], "total": sum(self.times),
                               "boards": [Play(p).t.count for p in self.puzzles], "hints": self.play.hints,
                               "completed_at": time.time()}
        return True

    def leave(self):
        if self.attack and self.state != "completed":
            self.timer.stop()
            self.state = "incomplete"
        else:
            self.pause()

    def to_dict(self):
        if self.attack or self.state in ("completed", "incomplete"):
            raise ValueError("途中保存できないセッション")
        return {"play": self.play.to_dict(), "elapsed": self.timer.elapsed(), "bounds": list(self.bounds)}

    @classmethod
    def from_dict(cls, data, **clocks):
        import math
        play = Play.from_dict(data["play"])
        elapsed = data["elapsed"]
        bounds = data["bounds"]
        if (type(elapsed) not in (int, float) or not math.isfinite(elapsed) or elapsed < 0
                or not isinstance(bounds, list) or len(bounds) != 2
                or any(type(x) is not int for x in bounds) or not 2 <= bounds[0] <= bounds[1] <= 14):
            raise ValueError("保存時間・構成範囲が不正")
        result = cls([play.puzzle], bounds=bounds, **clocks)
        result.play = play
        result.timer.accumulated = elapsed
        result.state = "paused"
        return result
