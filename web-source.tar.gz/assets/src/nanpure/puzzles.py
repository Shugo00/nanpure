"""Offline puzzle generation, canonical identity and a bundled catalogue."""
from dataclasses import dataclass, asdict
import hashlib
import json
from pathlib import Path
import random
from .topology import get_topology
from .solver import solve_count, SearchLimit
from .reasoning import evaluate

DIFFICULTIES = ("easy", "normal", "hard", "very_hard")
LABELS = dict(zip(DIFFICULTIES, ("イージー", "ノーマル", "ハード", "ベリーハード")))
ALPHABET = "0123456789ABCDEFG"


def encode(values):
    return "".join(ALPHABET[v] for v in values)


def decode(text):
    return [ALPHABET.index(c) for c in text]


def canonical_key(t, givens):
    variants = []
    for swap in (False, True):
        for sy in (-1, 1):
            for sx in (-1, 1):
                items = [(sy*(c if swap else r), sx*(r if swap else c), v) for (r, c), v in zip(t.coords, givens)]
                oy, ox = min(y for y, x, v in items), min(x for y, x, v in items)
                labels = {0: 0}
                encoded = []
                for y, x, v in sorted(items):
                    if v not in labels:
                        labels[v] = len(labels)
                    encoded.append((y-oy, x-ox, labels[v]))
                variants.append(tuple(encoded))
    return hashlib.sha256(repr((t.n, min(variants))).encode()).hexdigest()


@dataclass
class Puzzle:
    id: str
    topology: str
    givens: str
    solution: str
    rating: dict
    seed: int
    generator: str = "g1"

    @property
    def difficulty(self):
        return self.rating["difficulty"]

    def validate(self):
        t = get_topology(self.topology)
        g, s = decode(self.givens), decode(self.solution)
        t.check_values(g)
        if not t.complete_valid(s) or any(v and v != s[i] for i, v in enumerate(g)):
            raise ValueError("問題と解の不整合")
        if self.difficulty not in DIFFICULTIES or self.id != canonical_key(t, g):
            raise ValueError("問題ID・難易度の不整合")
        return self

    def to_dict(self):
        return asdict(self)


def complete(t, rng):
    initial = [0]*len(t.coords)
    if t.form == "composite":
        # Seed a small, consistent subset to avoid pathological empty-grid search
        # in cyclic overlaps. Remaining cells still use randomized search.
        witness = [(r*3+r//3+c) % 9+1 for r,c in t.coords]
        for i in rng.sample(range(len(initial)), len(initial)//4):
            initial[i] = witness[i]
    result = solve_count(t, initial, limit=1, rng=rng, node_limit=500 if t.count >= 12 else 5000)
    if result.solution is None:
        raise ValueError("解なし")
    return result.solution


def generate(topology,seed,clue_fraction=None):
    t=get_topology(topology)
    rng=random.Random(seed)
    solution=complete(t,rng)
    values=solution[:]
    order=list(range(len(values)))
    rng.shuffle(order)
    target=int(len(values)*(clue_fraction if clue_fraction is not None else rng.uniform(.23,.42)))
    bounded = t.count >= 12
    count=len(values)
    def remove(indices):
        nonlocal count
        old=[values[i] for i in indices]
        for i in indices:values[i]=0
        try:unique=solve_count(t,values,node_limit=200 if bounded else 10000).count==1
        except SearchLimit:unique=False
        if unique:
            count-=len(indices)
            return
        for i,v in zip(indices,old):values[i]=v
        if len(indices)>1:
            middle=len(indices)//2
            remove(indices[:middle]);remove(indices[middle:])
    cursor,batch=0,32 if t.form == "composite" else 1
    while cursor<len(order) and count>target:
        # At sparse stages, a rejected batch can double the expensive checks.
        # Only group removals while there are still abundant clues.
        if count<=len(values)*.55:batch=1
        size=min(batch,count-target,len(order)-cursor)
        before=count
        remove(order[cursor:cursor+size])
        cursor+=size
        if t.form == "composite" and count>len(values)*.55:
            batch=min(32,batch*2) if before-count==size else max(1,batch//2) if before-count<size/2 else batch
    rating=evaluate(t,values)
    if rating is None:return None
    return Puzzle(canonical_key(t,values),topology,encode(values),encode(solution),rating,seed,'g4' if bounded else 'g3')

class Catalog:
    def __init__(self, directory=None):
        self.directory = Path(directory) if directory else Path(__file__).with_name("data")
        self.puzzles = []
        for path in sorted(self.directory.glob("*.jsonl")):
            self.puzzles.extend(Puzzle(**json.loads(line)) for line in path.read_text(encoding="utf-8").splitlines() if line.strip())

    def choose(self, form, difficulty, count=1, bounds=(2, 14), seen=(), rng=None):
        rng = rng or random.Random()
        seen = set(seen)
        candidates = [p for p in self.puzzles if get_topology(p.topology).form == form and p.difficulty == difficulty
                      and (form != "composite" or bounds[0] <= get_topology(p.topology).count <= bounds[1])]
        unseen = [p for p in candidates if p.id not in seen]
        if len(unseen) >= count:
            candidates = unseen
        if len(candidates) < count:
            raise ValueError("この条件の検証済み問題が不足している")
        return rng.sample(candidates, count)
