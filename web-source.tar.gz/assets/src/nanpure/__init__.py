"""Nanpure: the same Python puzzle and play core on desktop and web."""
__version__ = "0.1.0-dev"
