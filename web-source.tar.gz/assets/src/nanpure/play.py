"""Values, manual notes and reversible nested hypotheses, without a renderer."""
from copy import deepcopy
from .puzzles import Puzzle, decode
from .topology import get_topology
from .reasoning import candidates, next_step


class Play:
    def __init__(self, puzzle):
        self.puzzle = puzzle.validate()
        self.t = get_topology(puzzle.topology)
        self.givens = decode(puzzle.givens)
        self.values = self.givens[:]
        self.notes = [0]*len(self.values)
        self.owners = [0]*len(self.values)
        self.stack = []
        self.frames = {}
        self.serial = 0
        self.past, self.future = [], []
        self.ui = {"note": False, "fixed": 0, "fixed_mode": False, "selected": -1, "zoom": 1.0, "pan": [0.0, 0.0]}
        self.auto_delete = True
        self.hints = 0
        self.advice = None
        self.hint_stage = 0
        self._hint_values = None
        self._hint_domains = None

    def snapshot(self):
        return [self.values[:], self.notes[:], self.owners[:]]

    def _record(self, before, stack):
        changes = [[i, before[0][i], self.values[i], before[1][i], self.notes[i], before[2][i], self.owners[i]]
                   for i in range(len(self.values))
                   if (before[0][i], before[1][i], before[2][i]) != (self.values[i], self.notes[i], self.owners[i])]
        if not changes and stack == self.stack:
            return False
        self.past.append({"changes": changes, "before": stack, "after": self.stack[:]})
        self.future.clear()
        self.advice = None
        return True

    def edit(self, i, value, note=None):
        if type(i) is not int or not 0 <= i < len(self.values) or self.givens[i]:
            return False
        if type(value) is not int or not 0 <= value <= self.t.n:
            return False
        note = self.ui["note"] if note is None else note
        if note and self.values[i] and value:
            return False
        before, stack = self.snapshot(), self.stack[:]
        owner = self.stack[-1] if self.stack else 0
        if note and value:
            self.notes[i] ^= 1 << (value-1)
            self.owners[i] = owner
        else:
            if self.values[i] == value and (value or not self.notes[i]):
                return False
            self.values[i], self.notes[i], self.owners[i] = value, 0, owner
            if value and self.auto_delete:
                bit = 1 << (value-1)
                for j in self.t.peers[i]:
                    if self.notes[j] & bit:
                        self.notes[j] &= ~bit
                        self.owners[j] = owner
        return self._record(before, stack)

    def begin(self):
        before, stack = self.snapshot(), self.stack[:]
        self.serial += 1
        self.frames[self.serial] = before
        self.stack.append(self.serial)
        return self._record(before, stack)

    def accept(self):
        if not self.stack:
            return False
        before, stack = self.snapshot(), self.stack[:]
        old = self.stack.pop()
        parent = self.stack[-1] if self.stack else 0
        self.owners = [parent if o == old else o for o in self.owners]
        return self._record(before, stack)

    def rollback(self):
        if not self.stack:
            return False
        before, stack = self.snapshot(), self.stack[:]
        frame = self.frames[self.stack.pop()]
        self.values, self.notes, self.owners = [a[:] for a in frame]
        return self._record(before, stack)

    def _travel(self, edit, reverse):
        for i, old_v, new_v, old_n, new_n, old_o, new_o in edit["changes"]:
            self.values[i] = old_v if reverse else new_v
            self.notes[i] = old_n if reverse else new_n
            self.owners[i] = old_o if reverse else new_o
        self.stack = edit["before" if reverse else "after"][:]
        self.advice = None

    def undo(self):
        if not self.past:
            return False
        edit = self.past.pop()
        self._travel(edit, True)
        self.future.append(edit)
        return True

    def redo(self):
        if not self.future:
            return False
        edit = self.future.pop()
        self._travel(edit, False)
        self.past.append(edit)
        return True

    @property
    def complete(self):
        return self.t.complete_valid(self.values)

    def hint(self):
        values_key = tuple(self.values)
        if values_key != self._hint_values:
            self._hint_values, self._hint_domains = values_key, None
            self.advice = None
        if self.advice is not None:
            if self.hint_stage < 2:
                self.hint_stage += 1
                if self.hint_stage == 2 and not isinstance(self.advice, dict):
                    # Only proved, fully explained eliminations carry forward.
                    # Manual notes never supply premises or change these domains.
                    for i, mask in self.advice.removals:
                        self._hint_domains[i] &= ~mask
                return self.advice
            if isinstance(self.advice, dict) or self.advice.placements:
                return self.advice
            self.advice = None
        solution = decode(self.puzzle.solution)
        wrong = tuple(i for i, v in enumerate(self.values) if v and v != solution[i])
        if wrong:
            self.advice = {"wrong": wrong}
        else:
            if self._hint_domains is None:
                self._hint_domains = candidates(self.t, self.values)
            self.advice = next_step(self.t, self.values, self._hint_domains)
        self.hint_stage = 0
        if self.advice is not None:
            self.hints += 1
        return self.advice

    def to_dict(self):
        return deepcopy({"puzzle": self.puzzle.to_dict(), "values": self.values, "notes": self.notes,
                         "owners": self.owners, "stack": self.stack, "frames": self.frames, "serial": self.serial,
                         "past": self.past, "future": self.future, "ui": self.ui,
                         "auto_delete": self.auto_delete, "hints": self.hints})

    @classmethod
    def from_dict(cls, data):
        p = cls(Puzzle(**data["puzzle"]))
        for key in ("values", "notes", "owners", "stack", "serial", "past", "future", "ui", "auto_delete", "hints"):
            setattr(p, key, deepcopy(data[key]))
        p.frames = {int(k): deepcopy(v) for k, v in data["frames"].items()}
        p.ui.setdefault("fixed_mode", bool(p.ui.get("fixed")))
        p._validate_saved()
        return p

    def _validate_saved(self):
        import math
        size = len(self.givens)
        def integer(v, lo, hi):
            return type(v) is int and lo <= v <= hi
        def stack_ok(stack):
            return (isinstance(stack, list) and len(stack) == len(set(stack))
                    and all(type(i) is int and i in self.frames for i in stack))
        def snapshot_ok(s):
            if not isinstance(s, list) or len(s) != 3 or any(not isinstance(a, list) or len(a) != size for a in s):
                return False
            return (all(integer(v, 0, self.t.n) for v in s[0])
                    and all(integer(n, 0, self.t.full) for n in s[1])
                    and all(type(o) is int and (o == 0 or o in self.frames) for o in s[2])
                    and all(not g or (s[0][i] == g and s[1][i] == s[2][i] == 0) for i, g in enumerate(self.givens))
                    and all(not v or not s[1][i] for i, v in enumerate(s[0])))
        if (not integer(self.serial, 0, 10**9) or any(not integer(k, 1, self.serial) for k in self.frames)
                or type(self.auto_delete) is not bool or not integer(self.hints, 0, 10**9)
                or not stack_ok(self.stack) or not snapshot_ok(self.snapshot())
                or not all(snapshot_ok(s) for s in self.frames.values())):
            raise ValueError("保存盤面・仮置きが不正")
        ui = self.ui
        if (type(ui.get("note")) is not bool or type(ui.get("fixed_mode")) is not bool or not integer(ui.get("fixed"), 0, self.t.n)
                or not integer(ui.get("selected"), -1, size-1)
                or type(ui.get("zoom")) not in (int, float) or not math.isfinite(ui["zoom"]) or not .1 <= ui["zoom"] <= 100
                or not isinstance(ui.get("pan"), list) or len(ui["pan"]) != 2
                or any(type(x) not in (int, float) or not math.isfinite(x) or abs(x) > 1e6 for x in ui["pan"])):
            raise ValueError("保存表示状態が不正")
        for edit in self.past+self.future:
            if not stack_ok(edit["before"]) or not stack_ok(edit["after"]):
                raise ValueError("保存履歴の階層が不正")
            indices = set()
            for change in edit["changes"]:
                if len(change) != 7:
                    raise ValueError("保存履歴の差分が不正")
                i, v0, v1, n0, n1, o0, o1 = change
                if (not integer(i, 0, size-1) or i in indices or self.givens[i]
                        or not all(integer(v, 0, self.t.n) for v in (v0, v1))
                        or not all(integer(n, 0, self.t.full) for n in (n0, n1))
                        or (v0 and n0) or (v1 and n1)
                        or any(type(o) is not int or (o != 0 and o not in self.frames) for o in (o0, o1))):
                    raise ValueError("保存履歴に範囲外の変更")
                indices.add(i)
        # Check both sides of every delta and the initial state, not just types.
        saved, stack = self.snapshot(), self.stack[:]
        def checked_travel(edit, reverse):
            if self.stack != edit["after" if reverse else "before"]:
                raise ValueError("保存履歴の階層が連続しない")
            for i, v0, v1, n0, n1, o0, o1 in edit["changes"]:
                expected = (v1, n1, o1) if reverse else (v0, n0, o0)
                if (self.values[i], self.notes[i], self.owners[i]) != expected:
                    raise ValueError("保存履歴の差分が連続しない")
            self._travel(edit, reverse)
            # The initial snapshot and both sides of every changed cell were
            # validated above. Unchanged cells preserve that invariant, so a
            # full-board scan for every delta would add size*history work.
        for edit in reversed(self.past):
            checked_travel(edit, True)
        if self.snapshot() != [self.givens, [0]*size, [0]*size] or self.stack:
            raise ValueError("保存履歴の開始状態が不正")
        for edit in self.past:
            checked_travel(edit, False)
        for edit in reversed(self.future):
            checked_travel(edit, False)
        self.values, self.notes, self.owners = saved
        self.stack = stack
