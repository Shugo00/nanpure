"""Environment bridge only: visibility, clocks and IndexedDB transactions."""
import json
import sys
import time
from .storage import validate, StorageError

WEB = sys.platform == "emscripten"


def js(source):
    from platform import window
    return window.eval("eval("+json.dumps(source, ensure_ascii=True)+")")


def value(expression):
    encoded = js("JSON.stringify("+expression+").replace(/[\\u007f-\\uffff]/g,c=>String.fromCharCode(92)+'u'+c.charCodeAt(0).toString(16).padStart(4,'0'))")
    return json.loads(str(encoded))


class Platform:
    def __init__(self):
        if WEB:
            js("""(() => {
              const state=window.__nanpure={lost:null,active:false,normal:true,results:{},serial:0};
              const cover=document.createElement('div');
              cover.style.cssText='position:fixed;inset:0;z-index:2147483647;background:#f4f7fa;color:#20344c;display:none;padding:40px;font:24px sans-serif';
              cover.textContent='一時停止';document.body.appendChild(cover);state.cover=cover;
              const lost=()=>{if(state.active&&state.normal){if(state.lost===null)state.lost=performance.now()/1000;cover.style.display='block';}};
              document.addEventListener('visibilitychange',()=>{if(document.hidden)lost();});
              window.addEventListener('blur',lost);
              const canvas=document.getElementById('canvas');
              if(canvas){canvas.style.touchAction='none';canvas.addEventListener('contextmenu',e=>e.preventDefault());}
              state.db=new Promise((resolve,reject)=>{
                const request=indexedDB.open('zatsu.nanpure.v1',1);
                request.onupgradeneeded=()=>request.result.createObjectStore('state');
                request.onsuccess=()=>resolve(request.result);
                request.onerror=()=>reject(new Error('IndexedDBを開けない'));
                request.onblocked=()=>reject(new Error('保存領域の更新が別タブで止められた'));
              });
              // Keep a rejection handler attached before Python issues its first request.
              state.db.catch(()=>{});
              state.request=(action,payload,expected)=>{
                const token=++state.serial;
                state.db.then(db=>new Promise((resolve,reject)=>{
                  const tx=db.transaction('state',action==='load'?'readonly':'readwrite');
                  const store=tx.objectStore('state');let result=null;let custom='';
                  const get=store.get('current');
                  get.onsuccess=()=>{
                    const old=get.result;
                    if(action==='load'){result=old??null;return;}
                    if((old?.revision??0)!==expected){custom='他の画面で保存されたため上書きできない';tx.abort();return;}
                    try {
                      if(old!==undefined)store.put(old,'backup');
                      payload.revision=expected+1;store.put(payload,'current');result=payload.revision;
                    } catch(error) {custom=String(error);tx.abort();}
                  };
                  tx.oncomplete=()=>resolve(result);
                  tx.onabort=tx.onerror=()=>reject(new Error(custom||String(tx.error||'保存失敗')));
                })).then(result=>state.results[token]={ok:true,result},error=>state.results[token]={ok:false,error:String(error)});
                return token;
              };
              return true;
            })()""")

    def mono(self):
        return float(js("performance.now()/1000")) if WEB else time.monotonic()

    def wall(self):
        return float(js("Date.now()/1000")) if WEB else time.time()

    def active(self, active, normal=True):
        if WEB:
            js("Object.assign(window.__nanpure,"+json.dumps({"active": active, "normal": normal})+")")

    def lost(self):
        if not WEB:
            return None
        result = value("window.__nanpure.lost")
        if result is not None:
            js("window.__nanpure.lost=null")
        return result

    def painted(self):
        if WEB:
            js("window.__nanpure.cover.style.display='none'")

    def size(self, native):
        return tuple(value("[window.innerWidth,window.innerHeight]")) if WEB else native


class WebStore:
    def request(self, action, data=None, revision=None):
        if action == "save":
            validate(data)
        return int(js("window.__nanpure.request("+json.dumps(action)+","+json.dumps(data, ensure_ascii=True, allow_nan=False)+","+json.dumps(revision)+")"))

    def poll(self, token):
        result = value(f"window.__nanpure.results[{token}]??null")
        if result is not None:
            js(f"delete window.__nanpure.results[{token}]")
        return result
