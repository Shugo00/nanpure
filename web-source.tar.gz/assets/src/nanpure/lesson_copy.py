"""Worked explanations for the 9×9 lessons, using the marks on the displayed board."""

from .solver import bits


def _digits(mask):
    return [bit.bit_length() for bit in bits(mask)]


def _list(numbers):
    return "・".join(map(str, numbers))


def _cell(t, cell):
    row, col = t.coords[cell]
    return f"{row+1}行{col+1}列"


def _unit(t, unit):
    coords = [t.coords[i] for i in t.units[unit]]
    row, col = coords[0]
    if all(r == row for r, c in coords):
        return f"{row+1}行目"
    if all(c == col for r, c in coords):
        return f"{col+1}列目"
    position = (("左上", "上中央", "右上"),
                ("左中央", "中央", "右中央"),
                ("左下", "下中央", "右下"))
    return position[row // 3][col // 3] + "の3×3の枠"


def _places(t, cells, unit):
    """Within a line, name only the other axis so the eye can follow it."""
    coords = [t.coords[i] for i in cells]
    if unit.endswith("行目"):
        return "と".join(f"{c+1}列目" for r, c in coords)
    if unit.endswith("列目"):
        return "と".join(f"{r+1}行目" for r, c in coords)
    return "と".join(_cell(t, i) for i in cells)


def _scan(lesson, t, cell):
    # These lessons use the single standard board: row, column, then 3×3 box.
    values = lesson.data["values"]
    seen = set()
    groups = []
    for unit, label in zip(t.memberships[cell], ("同じ行", "同じ列", "同じ3×3の枠")):
        new = {values[i] for i in t.units[unit]} - seen - {0}
        if new:
            groups.append(f"{label}に{_list(sorted(new))}")
            seen.update(new)
    choices = _digits(lesson.data["domains"][cell])
    if len(seen) + len(choices) != t.n:
        # Some marks may already have been crossed out by an earlier deduction.
        return f"{_cell(t, cell)}の小さな数字を見ると，{choices[0]}だけが残っている．ここには{choices[0]}が入る．"
    return (f"{_cell(t, cell)}を見よう．" + "，".join(groups) + "がある．"
            + f"これらを外すと，残るのは{_list(choices)}だけ．")


def _contradiction(t, error):
    if error["kind"] == "empty_cell":
        return f"{_cell(t, error['cell'])}に入る数字がなくなる"
    where = _unit(t, error["unit"])
    if error["kind"] == "duplicate":
        return f"{where}に{error['digit']}が2つ並んでしまう"
    return f"{where}のどこにも{_list(_digits(error['mask']))}を置けなくなる"


def _branches(t, proof):
    branches = proof["branches"]
    where = _cell(t, branches[0]["cell"])
    options = "と".join(str(b["digit"]) for b in branches)
    lines = [f"{where}に残る候補は{options}．"]
    for branch in branches:
        child = branch["proof"]
        if "contradiction" in child:
            lines.append(f"{branch['digit']}を試すと，{_contradiction(t, child['contradiction'])}．")
        else:
            lines.append(f"{branch['digit']}を試す．" + _branches(t, child))
    return "".join(lines)


def _trial(t, proof):
    cell, digit = proof["assumption"]
    where = _cell(t, cell)
    start = f"{where}に{digit}を仮に置いてみよう．"
    if "branches" in proof:
        return (start + "決まるマスを埋めていくと，"
                + _branches(t, proof) + f"どの候補を試しても行き詰まる．だから最初の{where}に{digit}は入らない．")
    trace = proof["trace"]
    if trace:
        next_cell, next_digit = trace[0][1][0]
        start += f"すると{_cell(t, next_cell)}は{next_digit}に決まる．"
    consequence = "決まるマスを順に埋めていくと，" if len(trace) > 1 else ""
    return start + consequence + _contradiction(t, proof["contradiction"]) + f"．だから最初の{where}に{digit}は入らない．"


def _xwing(t, step, digit):
    # The first two corners in the recorded proof belong to its first line.
    corners = [t.coords[i] for i in step.premises]
    along_rows = corners[0][0] == corners[1][0]
    first, other = ("行目", "列目") if along_rows else ("列目", "行目")
    axis = 0 if along_rows else 1
    a, b = sorted({coord[axis] + 1 for coord in corners})
    x, y = sorted({coord[1-axis] + 1 for coord in corners})
    return (f"{a}{first}でも{b}{first}でも，{digit}が入るのは{x}{other}か{y}{other}だけ．"
            f"2つの{digit}は同じ{other[0]}には置けないので，{x}{other}と{y}{other}に1つずつ入る．")


def worked_explanation(lesson, topology, cell=None, digit=None):
    """Explain the example, or the specific correct move made in an exercise."""
    t = topology
    step = lesson.step
    if lesson.topic == "candidates":
        return _scan(lesson, t, lesson.data["cell"])
    if step.placements:
        target, value = step.placements[0]
        if lesson.topic == "naked_single":
            return _scan(lesson, t, target)
        unit = _unit(t, step.units[0])
        return (f"{unit}で，小さな{value}を探してみよう．{value}が候補に残っているのは"
                f"{_cell(t, target)}だけ．だからここに{value}が入る．")
    if lesson.topic in ("trial", "nested_trial"):
        return _trial(t, step.proof)

    if cell is None:
        cell = step.removals[0][0]
    if digit is None:
        digit = _digits(dict(step.removals)[cell])[0]
    action = f"{_cell(t, cell)}のメモから{digit}を消せる．"
    if lesson.topic == "xwing":
        return _xwing(t, step, digit) + action
    unit = _unit(t, step.units[0])
    places = _places(t, step.premises, unit)
    if lesson.topic == "locked":
        other = _unit(t, step.units[1])
        choice = "どちら" if len(step.premises) == 2 else "どこ"
        return (f"{unit}で{digit}が入るのは，{places}だけ．{choice}に置いても"
                f"{other}で{digit}を使う．だから" + action)
    domains = lesson.data["domains"]
    if lesson.topic == "naked_pair":
        a, b = _digits(domains[step.premises[0]])
        return (f"{unit}の{places}には，どちらも{a}と{b}しか入らない．"
                f"片方が{a}ならもう片方が{b}．この2マスで両方使うので，" + action)
    if lesson.topic == "hidden_pair":
        first, second = step.premises
        pair = domains[first] & domains[second]
        for i in t.units[step.units[0]]:
            if i not in (first, second):
                pair &= ~domains[i]
        a, b = _digits(pair)
        return (f"{unit}で{a}と{b}のメモを探すと，{places}にしかない．"
                f"この2マスは{a}と{b}で埋まるので，" + action)
    raise ValueError(f"Unknown lesson topic: {lesson.topic}")
