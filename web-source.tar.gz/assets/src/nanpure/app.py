"""Pygame presentation: all rule changes are delegated to the common core."""
import asyncio
from functools import lru_cache
import math
import os
from pathlib import Path
import pygame as pg
from .puzzles import Catalog, DIFFICULTIES, LABELS, decode
from .topology import get_topology
from .play import Play
from .session import Session
from .storage import FileStore, SaveManager, StorageError, empty_state, add_record, validate
from .platforms import WEB, Platform, WebStore
from .view import View, TouchGesture
from .lessons import Lesson, TOPICS

BG = (242, 246, 250)
WHITE = (255, 255, 255)
INK = (32, 52, 76)
MUTED = (100, 119, 140)
BLUE = (35, 99, 146)
PALE = (227, 239, 248)
LINE = (201, 214, 226)
GOLD = (197, 146, 39)
TRIAL = ((187, 98, 14), (140, 71, 157), (22, 128, 126))
FORMS = {"standard": "標準 9×9", "large": "16×16", "composite": "複合"}


@lru_cache(maxsize=64)
def _font(size):
    return pg.font.Font(str(Path(__file__).with_name("assets")/"NotoSansCJKjp-Regular.otf"), size)


def font(size):
    return _font(max(7, int(size)))


def duration(seconds):
    seconds = int(seconds)
    return f"{seconds//3600}:{seconds//60%60:02}:{seconds%60:02}" if seconds >= 3600 else f"{seconds//60:02}:{seconds%60:02}"


class App:
    def __init__(self, screen, catalog, data, platform, store=None):
        self.screen = screen
        self.catalog = catalog
        self.platform = platform
        self.saves = SaveManager(data, store)
        self.webstore = WebStore() if WEB else None
        self.save_token = None
        self.page = "menu"
        self.form = "standard"
        self.difficulty = "easy"
        self.attack = False
        self.bounds = [2, 14]
        self.session = None
        self.lesson = None
        self.lesson_play = None
        self.view = None
        self.buttons = []
        self.focus = -1
        self.running = True
        self.quit_requested = False
        self.message = ""
        self.confirm = None
        self.pending_digits = ""
        self.fixed_mode = False
        self.gesture = TouchGesture()
        self.pointer = None
        self.pointer_drag = False
        self.pointer_panned = False
        self.record_page = 0
        self.last_save = self.platform.mono()
        self.last_size = screen.get_size()
        self.control_scroll = 0
        self.control_limit = 0
        self.control_rect = None
        self.menu_scroll = 0
        self.menu_limit = 0
        self.dialog_message = None
        self.dialog_page = 0

    @property
    def mobile(self):
        w, h = self.screen.get_size()
        return w < 880 and h >= w

    @property
    def modal(self):
        return bool(self.confirm or (self.page == "play" and
                    (self.session.state in ("paused", "completed") or
                     (self.message and self.screen.get_width() < 880))))

    @property
    def play(self):
        return self.lesson_play if self.page == "lesson" else self.session.play if self.session else None

    def text(self, text, pos, size=18, color=INK, center=False):
        surface = font(size).render(str(text), True, color)
        rect = surface.get_rect(center=pos) if center else surface.get_rect(topleft=pos)
        self.screen.blit(surface, rect)
        return rect

    def text_lines(self, text, width, size=15):
        lines, line = [], ""
        for c in str(text):
            if c == "\n" or (line and font(size).size(line+c)[0] > width):
                lines.append(line)
                line = ""
            if c != "\n":
                line += c
        if line or not lines:
            lines.append(line)
        return lines

    def wrap(self, text, rect, size=15, color=MUTED):
        rect = pg.Rect(rect)
        for i, line in enumerate(self.text_lines(text, rect.w, size)):
            y = rect.y+i*(size+7)
            if y+size > rect.bottom:
                break
            self.text(line, (rect.x, y), size, color)

    def flow(self, text, x, y, width, size=15, color=MUTED):
        """Full text height is part of the scrollable content, including off-screen lines."""
        height = len(self.text_lines(text, width, size))*(size+7)
        self.wrap(text, (x, y, width, height), size, color)
        return height

    def button(self, label, rect, action, selected=False, enabled=True, size=16):
        rect = pg.Rect(rect)
        index = len(self.buttons)
        hover = rect.collidepoint(pg.mouse.get_pos())
        color = BLUE if selected else PALE if hover and enabled else WHITE
        pg.draw.rect(self.screen, color, rect, border_radius=7)
        pg.draw.rect(self.screen, GOLD if self.focus == index else LINE, rect, 2 if self.focus == index else 1, border_radius=7)
        fit = min(size, max(10, int(size*(rect.w-10)/max(1, font(size).size(label)[0]))))
        self.text(label, rect.center, fit, WHITE if selected else INK if enabled else MUTED, True)
        self.buttons.append((rect.clip(self.screen.get_clip()), action if enabled else None))

    def row(self, labels, rect, actions, selected=-1, size=16):
        x, y, w, h = rect
        gap = 7
        item_width = (w-gap*(len(labels)-1))/len(labels)
        for i, label in enumerate(labels):
            self.button(label, (x+i*(item_width+gap), y, item_width, h), actions[i], selected=i == selected, size=size)

    def changed(self, persistent=False):
        if self.page == "play" and self.session and not self.session.attack and self.session.state not in ("completed", "incomplete"):
            self.save_view()
            self.saves.data["slots"][self.session.play.t.form] = self.session.to_dict()
            persistent = True
        if persistent:
            self.saves.changed()

    def cancel_pointer(self):
        # A background switch may swallow finger-up / mouse-up events.
        self.gesture = TouchGesture()
        self.pointer, self.pointer_drag, self.pointer_panned = None, False, False

    def save_view(self):
        if self.view and self.play:
            # Scale is in logical pixels per cell; center in cell coordinates survives resize.
            vx, vy, vw, vh = self.view.viewport
            center = self.view.world((vx+vw/2, vy+vh/2))
            fit = min((vw-12)/self.play.t.width, (vh-12)/self.play.t.height)
            self.play.ui["zoom"] = self.view.scale/fit
            self.play.ui["pan"] = list(center)

    def setup_view(self, restore=False):
        p = self.play
        if p is None:
            return
        w, h = self.screen.get_size()
        mobile = self.mobile
        if mobile:
            controls = 370 if p.t.n == 9 else 412
            viewport = (12, 114, w-24, max(100, h-controls-130))
        else:
            viewport = (24, 114, w-380, h-156)
        self.view = View(p.t.width, p.t.height, viewport)
        from collections import Counter
        self.shared = {i for i,n in Counter(i for board in p.t.boards for i in board).items() if n>1}
        self.view.fit()
        if restore and p.ui["pan"] != [0.0, 0.0]:
            self.view.scale *= p.ui["zoom"]
            r, c = p.ui["pan"]
            vx, vy, vw, vh = viewport
            self.view.x, self.view.y = vx+vw/2-c*self.view.scale, vy+vh/2-r*self.view.scale
            self.view.clamp()

    def start(self, confirmed=False):
        if not self.attack and self.form in self.saves.data["slots"] and not confirmed:
            self.confirm = ("この形式の途中保存を新しい問題で置き換える．他の形式の保存は残る．", lambda: self.start(True))
            return
        try:
            puzzles = self.catalog.choose(self.form, self.difficulty, 3 if self.attack else 1,
                                          self.bounds, self.saves.data["seen"])
            self.session = Session(puzzles, self.attack, self.bounds, self.platform.mono, self.platform.wall)
            self.session.play.auto_delete = self.saves.data["settings"]["auto_delete"]
            self.saves.data["seen"] = list(dict.fromkeys(self.saves.data["seen"]+[p.id for p in puzzles]))[-20000:]
            self.page, self.message, self.pending_digits = "play", "", ""
            self.fixed_mode = False
            self.control_scroll = 0
            self.setup_view()
            self.changed(True)  # Seen IDs also persist when starting a TA.
        except ValueError as e:
            self.message = str(e)

    def restore(self):
        try:
            self.session = Session.from_dict(self.saves.data["slots"][self.form], monotonic=self.platform.mono, wall=self.platform.wall)
            self.session.play.auto_delete = self.saves.data["settings"]["auto_delete"]
            self.page, self.message, self.pending_digits = "play", "", ""
            self.fixed_mode = self.play.ui["fixed_mode"]
            self.control_scroll = 0
            self.setup_view(True)
        except (ValueError, KeyError) as e:
            self.message = f"再開できない：{e}"

    def leave(self, confirmed=False):
        if self.page == "play" and self.session.attack and self.session.state not in ("completed", "incomplete") and not confirmed:
            self.confirm = ("タイムアタックを未完走で終了する．この回の記録は残らない．", lambda: self.leave(True))
            return
        if self.page == "play":
            self.session.leave()
            self.changed()
        self.page, self.lesson, self.message = "menu", None, ""
        self.platform.active(False)

    def choose_form(self, form):
        self.form = form

    def bound(self, index, amount):
        self.bounds[index] = max(2, min(14, self.bounds[index]+amount))
        self.bounds[1-index] = max(self.bounds) if index == 0 else min(self.bounds)

    def set_note(self, note):
        self.play.ui["note"] = note
        self.pending_digits = ""
        self.changed()

    def set_fixed(self, fixed):
        self.fixed_mode = fixed
        self.play.ui["fixed_mode"] = fixed
        if not fixed:
            self.play.ui["fixed"] = 0
        self.pending_digits = ""
        self.changed()

    def number(self, digit, keyboard=False):
        if self.page == "lesson":
            if self.lesson.index == 0:
                return
            self.lesson.answer(self.play.ui["selected"], digit, self.play.t)
            if self.lesson.topic == "candidates":
                self.play.notes[self.lesson.data["cell"]] = self.lesson.mask
            return
        if not self.session or self.session.state != "playing":
            return
        if self.fixed_mode:
            self.play.ui["fixed"] = digit
            self.changed()
        elif self.play.edit(self.play.ui["selected"], digit):
            self.changed()
        self.pending_digits = ""

    def select(self, point):
        if not self.view or not pg.Rect(self.view.viewport).collidepoint(point):
            return
        if self.page == "play" and self.session.state != "playing":
            return
        r, c = self.view.world(point)
        i = self.play.t.index().get((math.floor(r), math.floor(c)))
        if i is None:
            return
        self.pending_digits = ""
        self.play.ui["selected"] = i
        if self.page == "play":
            if self.fixed_mode and self.play.ui["fixed"]:
                self.play.edit(i, self.play.ui["fixed"])
            self.changed()

    def action(self, name):
        if not self.session or self.session.state != "playing":
            return
        p = self.play
        if name in ("undo", "redo", "begin", "accept", "rollback"):
            getattr(p, name)()
        elif name == "erase":
            p.edit(p.ui["selected"], 0)
        elif name == "hint":
            self.session.hint()
            if p.advice and self.screen.get_width() < 880:
                self.message = ("強調した数字が正解と一致していない．関係する行・列・区画を確認して自分で直す．"
                                if isinstance(p.advice, dict) else p.advice.text(p.t, p.hint_stage))
        elif name == "pause":
            self.session.pause()
        elif name == "auto":
            p.auto_delete = not p.auto_delete
            self.saves.data["settings"]["auto_delete"] = p.auto_delete
        self.pending_digits = ""
        self.changed(name == "auto")

    def focus_board(self):
        i = self.play.ui["selected"]
        containing = [b for b, cells in enumerate(self.play.t.boards) if i in cells]
        board = containing[0] if containing else 0
        r, c = self.play.t.origins[board]
        self.view.fit((r, c, self.play.t.n, self.play.t.n))
        self.changed()

    def zoom(self, factor):
        rect = pg.Rect(self.view.viewport)
        self.view.zoom(factor, rect.center)
        self.changed()

    def fit(self):
        self.view.fit()
        self.changed()

    def draw_menu(self):
        w, h = self.screen.get_size()
        width = min(670, w-32)
        x = (w-width)/2
        self.text("ナンプレ", (x, 32), 32)
        self.text("メモを取り，仮置きを戻し，一手ずつ考える．", (x, 80), min(16, int(width/25)), MUTED)
        y = 130
        self.row(list(FORMS.values()), (x, y, width, 50), [lambda k=k: self.choose_form(k) for k in FORMS], list(FORMS).index(self.form))
        y += 76
        self.text("難易度", (x, y), 16, MUTED)
        y += 30
        self.row([LABELS[k] for k in DIFFICULTIES], (x, y, width, 46),
                 [lambda k=k: setattr(self, "difficulty", k) for k in DIFFICULTIES], DIFFICULTIES.index(self.difficulty), 15)
        y += 70
        self.row(["通常 · 1問", "タイムアタック · 3問"], (x, y, width, 48),
                 [lambda: setattr(self, "attack", False), lambda: setattr(self, "attack", True)], int(self.attack))
        y += 64
        if self.form == "composite":
            self.text(f"構成枚数　{self.bounds[0]}〜{self.bounds[1]}枚", (x, y), 17)
            y += 32
            self.row(["下限 −", "下限 ＋", "上限 −", "上限 ＋"], (x, y, width, 38),
                     [lambda: self.bound(0, -1), lambda: self.bound(0, 1), lambda: self.bound(1, -1), lambda: self.bound(1, 1)], size=14)
            y += 52
        self.button("新しい問題をはじめる", (x, y, width, 52), self.start, True)
        y += 66
        if self.form in self.saves.data["slots"]:
            self.button("通常の途中保存から再開", (x, y, width, 44), self.restore)
            y += 56
        self.row(["解法を学ぶ", "成績を見る"], (x, y, width, 44),
                 [lambda: setattr(self, "page", "learn_menu"), lambda: setattr(self, "page", "records")])
        self.wrap(self.message, (x, y+58, width, max(32, h-y-72)), 15, BLUE)

    def draw_board(self):
        p, view = self.play, self.view
        rect = pg.Rect(view.viewport)
        pg.draw.rect(self.screen, WHITE, rect, border_radius=8)
        previous_clip = self.screen.get_clip()
        self.screen.set_clip(rect)
        shared = self.shared
        selected = p.ui["selected"]
        hint_cells = set()
        clue_cells = ()
        if self.page == "play" and p.advice:
            hint_cells = set(p.advice["wrong"] if isinstance(p.advice, dict) else p.advice.cells)
        if self.page == "lesson":
            hint_cells = set(self.lesson.step.cells if self.lesson.step else [self.lesson.data["cell"]])
            clue_cells = self.lesson.clue_cells
        scale = view.scale
        for i, (r, c) in enumerate(p.t.coords):
            x, y = view.screen(r, c)
            cell = pg.Rect(round(x), round(y), math.ceil(scale), math.ceil(scale))
            if not rect.colliderect(cell):
                continue
            fill = PALE if i in shared or i in clue_cells else WHITE
            if i == selected and i not in clue_cells:
                fill = (255, 239, 186)
            pg.draw.rect(self.screen, fill, cell)
            pg.draw.rect(self.screen, LINE, cell, 1)
            v = p.values[i]
            if v:
                color = INK if p.givens[i] else TRIAL[(p.owners[i]-1) % 3] if p.owners[i] else BLUE
                self.text(v, cell.center, max(8, min(64, scale*.53)), color, True)
            elif p.notes[i] and scale >= 18:
                for v in range(1, p.t.n+1):
                    if p.notes[i] & (1 << (v-1)):
                        nr, nc = divmod(v-1, p.t.box)
                        point = (x+(nc+.5)*scale/p.t.box, y+(nr+.5)*scale/p.t.box)
                        self.text(v, point, min(20, max(7, scale/(p.t.box*1.48))), MUTED, True)
            if i in hint_cells:
                pg.draw.rect(self.screen, GOLD, cell.inflate(-2, -2), max(1, int(min(3, scale/10))))
            if i == selected and i in clue_cells:
                pg.draw.circle(self.screen, BLUE, (cell.left+5, cell.top+5), 2)
        for r, c in p.t.origins:
            n, box = p.t.n, p.t.box
            for line in range(0, n+1, box):
                x1, y1 = view.screen(r+line, c)
                x2, y2 = view.screen(r+line, c+n)
                pg.draw.line(self.screen, MUTED, (x1, y1), (x2, y2), 2)
                x1, y1 = view.screen(r, c+line)
                x2, y2 = view.screen(r+n, c+line)
                pg.draw.line(self.screen, MUTED, (x1, y1), (x2, y2), 2)
        self.screen.set_clip(previous_clip)
        pg.draw.rect(self.screen, LINE, rect, 1, border_radius=8)

    def minimap(self, rect):
        rect = pg.Rect(rect)
        t = self.play.t
        s = min(rect.w/t.width, rect.h/t.height)
        x, y = rect.centerx-t.width*s/2, rect.centery-t.height*s/2
        for r, c in t.origins:
            b = pg.Rect(x+c*s, y+r*s, t.n*s, t.n*s)
            pg.draw.rect(self.screen, WHITE, b)
            pg.draw.rect(self.screen, MUTED, b, 1)
            for k in range(t.box, t.n, t.box):
                pg.draw.line(self.screen, LINE, (x+c*s,y+(r+k)*s),(x+(c+t.n)*s,y+(r+k)*s))
                pg.draw.line(self.screen, LINE, (x+(c+k)*s,y+r*s),(x+(c+k)*s,y+(r+t.n)*s))
        r0, c0, r1, c1 = self.view.visible()
        visible = pg.Rect(x+c0*s, y+r0*s, max(1, (c1-c0)*s), max(1, (r1-r0)*s))
        tint = pg.Surface(visible.size, pg.SRCALPHA)
        tint.fill((219, 171, 61, 75))
        self.screen.blit(tint, visible)
        pg.draw.rect(self.screen, GOLD, visible, 2)

    def draw_controls(self):
        w, h = self.screen.get_size()
        p = self.play
        mobile = self.mobile
        if mobile:
            x, y, width = 12, pg.Rect(self.view.viewport).bottom+10, w-24
        else:
            x, y, width = w-332, 120, 308
        original_y = y
        self.control_rect = pg.Rect(x, y, width, max(1, h-y-10))
        old_clip = self.screen.get_clip()
        self.screen.set_clip(self.control_rect)
        y -= self.control_scroll
        bh = 34 if mobile else 38
        gap = 6
        if self.page == "lesson" and self.lesson.index == 0:
            if self.lesson.clue_cells:
                y += self.flow("水色のマスを見比べると，金枠から消せる数字がわかります．", x, y, width, 15, MUTED)+8
            elif self.lesson.topic == "candidates":
                y += self.flow("空きマスの小さな数字は，そこに入るかもしれない数字のメモです．これを「候補」と呼びます．", x, y, width, 15, MUTED)+8
            y += self.flow(self.lesson.example_text, x, y, width, 16, INK)+12
            self.button("練習へ", (x, y, width, bh), self.next_lesson)
            self.control_limit = max(0, y+bh+self.control_scroll-h+14)
            self.screen.set_clip(old_clip)
            return
        if self.page == "lesson":
            y += self.flow(self.lesson.instruction, x, y, width, 15, INK)+12
            if self.lesson.step and len(self.lesson.step.cells) > 1:
                y += self.flow("金枠はどれを選んでもかまいません．", x, y, width, 14)+8
        else:
            self.row(["数字", "メモ ON" if p.ui["note"] else "メモ"], (x, y, width, bh),
                     [lambda: self.set_note(False), lambda: self.set_note(True)], int(p.ui["note"]))
            y += bh+gap
            self.row(["マスを選ぶ", "数字を固定"], (x, y, width, bh),
                     [lambda: self.set_fixed(False), lambda: self.set_fixed(True)], int(self.fixed_mode))
            y += bh+gap
        columns = 4 if p.t.n == 16 else 3
        digit_height = 32 if mobile else 40
        for row in range(p.t.box):
            for col in range(columns):
                digit = row*columns+col+1
                selected = (self.lesson.mask & (1 << (digit-1)) != 0 if self.page == "lesson" and self.lesson.topic == "candidates"
                            else self.fixed_mode and p.ui["fixed"] == digit)
                self.button(str(digit), (x+col*(width+gap)/columns, y+row*(digit_height+gap), (width-gap*(columns-1))/columns, digit_height),
                            lambda digit=digit: self.number(digit), selected, size=20)
        y += p.t.box*(digit_height+gap)
        if self.page == "lesson":
            if self.lesson.topic == "candidates":
                self.button("答え合わせ", (x, y, width, bh), self.lesson.check_candidates)
                y += bh+gap
            if self.lesson.feedback:
                y += self.flow(self.lesson.feedback, x, y, width, 15, BLUE)+12
            self.button("次の練習" if self.lesson.index < 5 else "テーマ一覧へ",
                        (x, y, width, bh), self.next_lesson)
            self.control_limit = max(0, y+bh+self.control_scroll-h+14)
            self.screen.set_clip(old_clip)
            return
        self.row(["消す", "取り消し", "やり直し"], (x, y, width, bh),
                 [lambda: self.action("erase"), lambda: self.action("undo"), lambda: self.action("redo")], size=14)
        y += bh+gap
        self.row([f"仮置き開始 ({len(p.stack)})", "採用", "開始時へ戻す"], (x, y, width, bh),
                 [lambda: self.action("begin"), lambda: self.action("accept"), lambda: self.action("rollback")], size=13)
        y += bh+gap
        if not self.session.attack:
            next_hint = p.advice and not isinstance(p.advice, dict) and p.advice.removals and p.hint_stage == 2
            self.row([f"{'次のヒント' if next_hint else 'ヒント'} ({p.hints})", "一時停止"], (x, y, width, bh),
                     [lambda: self.action("hint"), lambda: self.action("pause")])
            y += bh+gap
        self.button("メモ自動削除："+("ON" if p.auto_delete else "OFF"), (x, y, width, bh), lambda: self.action("auto"), size=14)
        y += bh+gap
        if self.pending_digits:
            self.text(f"入力中：{self.pending_digits}　Enterで確定", (x, y), 14, BLUE)
        elif p.advice:
            if isinstance(p.advice, dict):
                advice = "強調した数字が正解と一致していない．関係する行・列・区画を確認して自分で直す．"
            else:
                advice = p.advice.text(p.t, p.hint_stage)
            if not mobile:
                y += self.flow(advice, x, y+8, width, 14, BLUE)+8
        self.control_limit = max(0, y+24+self.control_scroll-h+14)
        self.screen.set_clip(old_clip)

    def draw_play(self):
        w, h = self.screen.get_size()
        if self.view is None:
            self.setup_view()
        p = self.play
        self.button("戻る", (12, 16, 66, 36), self.leave, size=14)
        title = TOPICS[self.lesson.topic] if self.page == "lesson" else FORMS[p.t.form]+" · "+LABELS[p.puzzle.difficulty]
        self.text(title, (90, 14), 17 if w < 600 else 21)
        if self.page == "lesson":
            status = "例題" if self.lesson.index == 0 else f"練習 {self.lesson.index}/5"
        else:
            current = 0 if self.session.state == "completed" else self.session.timer.elapsed()
            status = (f"TA {self.session.index+1}/3" if self.session.attack else "通常")+"　"+duration(sum(self.session.times)+current)
            if p.t.form == 'composite':
                status += f" · {p.t.count}枚"
        self.text(status, (90, 43), 14, MUTED)
        self.minimap((w-86, 12, 72, 56))
        self.row(["全体へ", "選択盤面へ", "−", "＋"], (12, 76, w-24 if self.mobile else w-380, 30),
                 [self.fit, self.focus_board, lambda: self.zoom(1/1.3), lambda: self.zoom(1.3)], size=13)
        self.draw_board()
        self.draw_controls()
        if self.page == "play":
            if self.saves.error:
                self.wrap("未保存："+self.saves.error, (14, h-31, w-154, 30), 12, (163, 67, 44))
                self.button("保存再試行", (w-132, h-35, 120, 30), lambda: setattr(self.saves, "error", ""), size=13)
            elif w >= 880:
                self.text("変更あり · 保存待ち" if self.saves.pending else "自動保存済み" if not self.session.attack else "TAは途中保存なし",
                          (26, h-28), 12, MUTED)
            if self.message and w < 880:
                self.dialog(self.message, [("閉じる", lambda: setattr(self, "message", ""))])
            if self.session.state == "paused":
                self.dialog("一時停止中．再開ボタンから計時する．", [("再開", self.resume_play), ("メニュー", self.leave)])
            elif self.session.state == "completed":
                title = "完成！　"+duration(sum(self.session.times))
                if self.session.attack:
                    title += '\n'+'\n'.join(f'{i+1}問目：{get_topology(p.topology).count}枚 {duration(seconds)}'
                                           for i,(p,seconds) in enumerate(zip(self.session.puzzles,self.session.times)))
                else:
                    title += f'\nヒント {self.play.hints}回'
                if self.session.record is None:
                    title += "　時計の変化を検出したため正式記録なし．"
                self.dialog(title, [("メニューへ", self.leave)])

    def resume_play(self):
        self.session.resume()
        self.changed()

    def draw_learn_menu(self):
        w, h = self.screen.get_size()
        width = min(660, w-32)
        x = (w-width)/2
        self.text("解法を学ぶ", (x, 24), 28)
        self.text("例題を1問見てから，5問練習できます．", (x, 68), 15, MUTED)
        aliases = {"locked": "ロックされた候補", "naked_pair": "裸のペア", "hidden_pair": "隠れたペア"}
        for index, (key, title) in enumerate(TOPICS.items()):
            label = f"{title}（{aliases[key]}）" if key in aliases else title
            self.button(label, (x, 110+index*49, width, 41), lambda key=key: self.open_lesson(key, 0))
        self.button("メニューへ", (x, min(h-55, 566), width, 40), lambda: setattr(self, "page", "menu"))

    def open_lesson(self, topic, index):
        self.lesson = Lesson(topic, index)
        source = next(p for p in self.catalog.puzzles if p.id == self.lesson.data["source"])
        self.lesson_play = Play(source)
        self.lesson_play.values = self.lesson.data["values"][:]
        self.lesson_play.notes = self.lesson.data["domains"][:]
        if topic == "candidates" and index > 0:
            self.lesson_play.notes[self.lesson.data["cell"]] = 0
        self.lesson_play.givens = self.lesson_play.values[:]
        self.lesson_play.ui["selected"] = self.lesson.selected
        self.page = "lesson"
        self.control_scroll = 0
        self.message = ""
        self.setup_view()

    def next_lesson(self):
        if self.lesson.index == 5:
            self.page = "learn_menu"
        else:
            self.open_lesson(self.lesson.topic, self.lesson.index+1)

    def draw_records(self):
        w, h = self.screen.get_size()
        self.text("成績", (24, 24), 28)
        self.button("メニュー", (w-112, 22, 88, 38), lambda: setattr(self, "page", "menu"))
        records = self.saves.data["records"][::-1]
        self.text(f"最近の完成 {len(records)}件　条件別ベスト {len(self.saves.data['bests'])}件", (24, 76), 15, MUTED)
        row_height = 146 if w < 600 else 76
        per_page = max(1, (h-180)//row_height)
        start = self.record_page*per_page
        if start >= len(records):
            self.record_page = start = 0
        for i, r in enumerate(records[start:start+per_page]):
            y = 116+i*row_height
            line = f"{'TA' if r['mode']=='attack' else '通常'} · {FORMS[r['form']]} · {LABELS[r['difficulty']]}　{duration(r['total'])}"
            self.wrap(line, (24, y, w-48, 48 if w < 600 else 26), 16, INK)
            separator = "\n" if w < 600 and r['mode'] == 'attack' else " ／ "
            detail = separator.join(f"{b}枚 {duration(s)}" for b, s in zip(r["boards"], r["times"]))
            if r["form"] == "composite":
                detail = f"範囲{r['bounds'][0]}〜{r['bounds'][1]}枚"+("\n" if w < 600 else "　")+detail
            if r['mode'] == 'normal':
                detail = f"ヒント {r['hints']}回　"+detail
            self.wrap(detail, (24, y+(50 if w < 600 else 28), w-48, row_height-(54 if w < 600 else 32)), 13, MUTED)
        self.row(["前へ", "次へ", "条件別ベスト"], (24, h-58, w-48, 36),
                 [lambda: setattr(self, "record_page", max(0, self.record_page-1)),
                  lambda: setattr(self, "record_page", self.record_page+1), lambda: setattr(self, "page", "bests")], size=14)

    def draw_bests(self):
        w, h = self.screen.get_size()
        self.text("条件別ベスト", (24, 24), 26)
        self.button("成績へ", (w-110, 22, 86, 36), lambda: setattr(self, "page", "records"))
        # A pageable list keeps every condition accessible on small screens.
        records = sorted(self.saves.data["bests"].values(), key=lambda r: (r["form"], r["difficulty"], r["bounds"]))
        per_page = max(1, (h-150)//68)
        start = self.record_page*per_page
        if start >= len(records):
            self.record_page = start = 0
        for i, r in enumerate(records[start:start+per_page]):
            y = 90+i*68
            self.wrap(f"{'TA' if r['mode']=='attack' else '通常'} · {FORMS[r['form']]} · {LABELS[r['difficulty']]} · {r['bounds'] if r['form']=='composite' else ''}　{duration(r['total'])}",
                      (24, y, w-48, 60), 16, INK)
        self.row(["前へ", "次へ"], (24, h-54, w-48, 34),
                 [lambda: setattr(self, "record_page", max(0, self.record_page-1)), lambda: setattr(self, "record_page", self.record_page+1)])

    def dialog(self, message, actions):
        w, h = self.screen.get_size()
        shade = pg.Surface((w, h), pg.SRCALPHA)
        shade.fill((24, 40, 57, 255))
        self.screen.blit(shade, (0, 0))
        width = min(540, w-32)
        height = min(460, h-32)
        box = pg.Rect((w-width)/2, (h-height)/2, width, height)
        pg.draw.rect(self.screen, WHITE, box, border_radius=12)
        lines = self.text_lines(message, width-36, 17)
        per_page = max(1, (height-140)//24)
        pages = max(1, math.ceil(len(lines)/per_page))
        if self.dialog_message != message:
            self.dialog_message, self.dialog_page = message, 0
        self.dialog_page = min(self.dialog_page, pages-1)
        for i, line in enumerate(lines[self.dialog_page*per_page:(self.dialog_page+1)*per_page]):
            self.text(line, (box.x+18, box.y+18+i*24), 17, INK)
        self.buttons = []
        if pages > 1:
            self.row(["前へ", f"{self.dialog_page+1} / {pages}", "次へ"],
                     (box.x+18, box.bottom-110, width-36, 36),
                     [lambda: setattr(self, "dialog_page", max(0, self.dialog_page-1)), None,
                      lambda: setattr(self, "dialog_page", min(pages-1, self.dialog_page+1))], size=14)
        self.row([label for label, action in actions], (box.x+18, box.bottom-62, width-36, 44), [action for label, action in actions])

    def draw(self):
        native = self.screen
        menu = self.page not in ("play", "lesson")
        if menu:
            w, h = native.get_size()
            self.menu_limit = max(0, 760-h)
            self.menu_scroll = min(self.menu_scroll, self.menu_limit)
            self.screen = pg.Surface((w, max(h, 760)))
        self.screen.fill(BG)
        self.buttons = []
        if self.page == "menu":
            self.draw_menu()
        elif self.page in ("play", "lesson"):
            self.draw_play()
        elif self.page == "learn_menu":
            self.draw_learn_menu()
        elif self.page == "records":
            self.draw_records()
        else:
            self.draw_bests()
        if menu:
            native.fill(BG)
            native.blit(self.screen, (0, -self.menu_scroll))
            self.screen = native
            self.buttons = [(r.move(0, -self.menu_scroll).clip(native.get_rect()), a) for r,a in self.buttons]
        if self.confirm:
            message, action = self.confirm
            def accept():
                self.confirm = None
                action()
            self.dialog(message, [("戻る", lambda: setattr(self, "confirm", None)), ("続ける", accept)])

    def click(self, point):
        for rect, action in self.buttons:
            if rect.collidepoint(point):
                if action:
                    action()
                return
        if not self.modal and self.page in ("play", "lesson"):
            self.select(point)

    def key(self, event):
        if event.key == pg.K_TAB:
            self.focus = (self.focus+(-1 if event.mod & pg.KMOD_SHIFT else 1)) % max(1, len(self.buttons))
            return
        if event.key == pg.K_RETURN and 0 <= self.focus < len(self.buttons) and not self.pending_digits:
            action = self.buttons[self.focus][1]
            if action:
                action()
            return
        if self.modal or self.page not in ("play", "lesson"):
            return
        if self.page == "play" and self.session.state != "playing":
            return
        if getattr(event, "repeat", False):
            return
        if event.key == pg.K_ESCAPE:
            self.pending_digits = ""
        elif event.key == pg.K_m and self.page == "play":
            self.set_note(not self.play.ui["note"])
        elif event.key == pg.K_z and event.mod & pg.KMOD_CTRL:
            self.action("redo" if event.mod & pg.KMOD_SHIFT else "undo")
        elif event.key == pg.K_y and event.mod & pg.KMOD_CTRL:
            self.action("redo")
        elif event.key in (pg.K_BACKSPACE, pg.K_DELETE):
            if self.pending_digits:
                self.pending_digits = self.pending_digits[:-1]
            elif self.page == "play":
                self.action("erase")
        elif event.key in (pg.K_LEFT, pg.K_RIGHT, pg.K_UP, pg.K_DOWN):
            i = self.play.ui["selected"]
            if i < 0:
                self.play.ui["selected"] = 0
            else:
                dr, dc = {pg.K_LEFT: (0,-1), pg.K_RIGHT: (0,1), pg.K_UP: (-1,0), pg.K_DOWN: (1,0)}[event.key]
                r, c = self.play.t.coords[i]
                index = self.play.t.index()
                while True:
                    r, c = r+dr, c+dc
                    if not 0 <= r < self.play.t.height or not 0 <= c < self.play.t.width:
                        break
                    if (r, c) in index:
                        self.play.ui["selected"] = index[r,c]
                        break
            self.pending_digits = ""
            if self.page == "play":
                self.changed()
        elif event.key in (pg.K_RETURN, pg.K_KP_ENTER) and self.pending_digits:
            number = int(self.pending_digits)
            if 1 <= number <= self.play.t.n:
                self.number(number, True)
            else:
                self.pending_digits = ""
        elif getattr(event, "unicode", "") in tuple("0123456789"):
            self.focus = -1
            digit = event.unicode
            if self.play.t.n == 16:
                self.pending_digits = (self.pending_digits+digit)[-2:]
            elif digit != "0":
                self.number(int(digit), True)

    def event(self, event):
        if self.modal and event.type in (pg.MOUSEWHEEL, pg.MOUSEMOTION, pg.FINGERMOTION):
            return
        if event.type == pg.QUIT:
            if self.page == "play" and not self.session.attack:
                self.session.pause()
                self.changed()
            # Decide only after the last pending save has actually completed.
            self.quit_requested = True
        elif event.type == pg.WINDOWFOCUSLOST:
            self.cancel_pointer()
            # Browser SDL events may be delivered only after the tab resumes.
            # The JS bridge carries the actual blur timestamp and handles Web.
            if not WEB and self.page == "play" and not self.session.attack:
                self.session.pause()
                self.changed()
        elif event.type == pg.KEYDOWN:
            self.key(event)
        elif event.type == pg.MOUSEWHEEL and self.page not in ("play", "lesson"):
            self.menu_scroll = max(0, min(self.menu_limit, self.menu_scroll-event.y*40))
        elif event.type == pg.MOUSEWHEEL and self.page in ("play", "lesson") and self.view:
            point = pg.mouse.get_pos()
            if pg.Rect(self.view.viewport).collidepoint(point):
                self.view.zoom(1.15**event.y, point)
                self.changed()
            elif self.control_rect and self.control_rect.collidepoint(point):
                self.control_scroll = max(0, min(self.control_limit, self.control_scroll-event.y*35))
        elif event.type == pg.MOUSEBUTTONDOWN and not getattr(event, "touch", False):
            if event.button == 1:
                self.focus = -1
                self.pointer = event.pos
                self.pointer_drag = bool(pg.key.get_pressed()[pg.K_SPACE]) and self.view is not None and pg.Rect(self.view.viewport).collidepoint(event.pos)
                self.pointer_panned = self.pointer_drag
        elif event.type == pg.MOUSEMOTION and self.pointer_drag:
            self.view.pan(event.rel[0], event.rel[1])
        elif event.type == pg.MOUSEBUTTONUP and not getattr(event, "touch", False):
            if event.button == 1:
                if self.pointer_drag:
                    self.changed()
                elif self.pointer is not None and not self.pointer_panned and math.dist(self.pointer, event.pos) < 8:
                    self.click(event.pos)
                self.pointer, self.pointer_drag = None, False
        elif event.type in (pg.FINGERDOWN, pg.FINGERMOTION, pg.FINGERUP):
            w, h = self.screen.get_size()
            point = (event.x*w, event.y*h)
            if event.type == pg.FINGERDOWN:
                self.focus = -1
                self.gesture.down(event.finger_id, point)
            elif event.type == pg.FINGERMOTION:
                origin = self.gesture.origins.get(event.finger_id, point)
                if self.view and self.page in ("play", "lesson") and pg.Rect(self.view.viewport).collidepoint(origin):
                    self.gesture.move(event.finger_id, point, self.view)
                elif math.dist(origin, point) > 8:
                    self.gesture.consumed = True
                    old = self.gesture.fingers.get(event.finger_id, point)
                    if self.control_rect and self.control_rect.collidepoint(origin):
                        self.control_scroll = max(0, min(self.control_limit, self.control_scroll-(point[1]-old[1])))
                    if self.page not in ("play", "lesson"):
                        self.menu_scroll = max(0, min(self.menu_limit, self.menu_scroll-(point[1]-old[1])))
                    self.gesture.fingers[event.finger_id] = point
            else:
                tap = self.gesture.up(event.finger_id)
                if tap:
                    self.click(point)
                elif self.page == "play":
                    self.changed()

    def tick(self):
        size = self.platform.size(self.screen.get_size())
        if size != self.last_size:
            if self.play:
                self.save_view()
            self.screen = pg.display.set_mode(size, pg.RESIZABLE)
            self.last_size = size
            self.setup_view(True)
        lost = self.platform.lost()
        if lost is not None:
            self.cancel_pointer()
            if self.page == "play":
                self.session.pause(lost)
                self.changed()
        if self.page == "play":
            self.platform.active(self.session.state == "playing", not self.session.attack)
            if self.session.finish_puzzle():
                if self.session.state == "completed":
                    if self.session.record:
                        add_record(self.saves.data, self.session.record)
                    if not self.session.attack:
                        self.saves.data["slots"].pop(self.play.t.form, None)
                    self.saves.changed()
                else:
                    self.setup_view()
        else:
            self.platform.active(False)
        if self.page == "play" and not self.session.attack and self.session.state == "playing" and self.platform.mono()-self.last_save > 5:
            self.changed()
            self.last_save = self.platform.mono()
        if WEB:
            if self.save_token is not None:
                result = self.webstore.poll(self.save_token)
                if result is not None:
                    self.save_token = None
                    self.saves.complete(result["result"]) if result["ok"] else self.saves.fail(result["error"])
            if not self.saves.error:
                request = self.saves.begin()
                if request:
                    try:
                        self.save_token = self.webstore.request("save", *request)
                    except Exception as e:
                        self.saves.fail(e)
        elif not self.saves.error:
            self.saves.flush()
        if self.quit_requested:
            if self.saves.error and self.saves.pending:
                self.quit_requested = False
                self.confirm = ("保存できていない変更がある．終了すると失われる可能性がある．", lambda: setattr(self, "running", False))
            elif not self.saves.pending:
                self.running = False

    def after_paint(self):
        if self.page == "play":
            self.session.ready()
        self.platform.painted()
        if WEB and bool(getattr(self, "test_mode", False)):
            from .platforms import js
            p = self.play if self.page == "play" else None
            report = {"page": self.page, "size": self.screen.get_size(),
                      "buttons": [list(r) for r,a in self.buttons],
                      "values": p.values if p else [], "notes": p.notes if p else [],
                      "coords": p.t.coords if p else [], "view": [self.view.x,self.view.y,self.view.scale] if p else [],
                      "viewport": self.view.viewport if p else [],
                      "state": self.session.state if self.page == "play" else None,
                      "revision": self.saves.data["revision"], "error": self.saves.error,
                      "pending": self.saves.pending, "stack": p.stack if p else [],
                      "elapsed": self.session.timer.elapsed() if self.page == "play" else 0,
                      "puzzle_id": p.puzzle.id if p else None,
                      "boards": p.t.count if p else None,
                      "index": self.session.index if self.page == "play" else None,
                      "attack": self.session.attack if self.page == "play" else None,
                      "records": len(self.saves.data['records']),
                      "python": __import__('sys').version, "pygame": pg.version.ver}
            import json
            js("window.__nanpureReport="+json.dumps(report))


async def main():
    pg.init()
    pg.display.set_caption("ナンプレ")
    screen = pg.display.set_mode((1180, 820), pg.RESIZABLE)
    platform = Platform()
    screen.fill(BG)
    screen.blit(font(26).render("ナンプレを準備中…", True, INK), (30, 40))
    pg.display.flip()
    await asyncio.sleep(0)
    try:
        if WEB:
            store = WebStore()
            token = store.request("load")
            while (result := store.poll(token)) is None:
                await asyncio.sleep(0)
            if not result["ok"]:
                raise StorageError(result["error"])
            data = empty_state() if result["result"] is None else validate(result["result"])
        else:
            store = FileStore(os.environ.get("NANPURE_DATA_DIR"))
            data = store.load()
        catalog = Catalog()
        app = App(screen, catalog, data, platform, store)
        if WEB:
            from .platforms import value
            app.test_mode = value("new URLSearchParams(location.search).get('check')==='1'")
    except (OSError, StorageError, ValueError) as error:
        # Preserve corrupt/unknown data. Do not silently start a writable empty game.
        screen.fill(BG)
        screen.blit(font(22).render("起動できない．既存の保存は変更していない．", True, INK), (20, 35))
        message = str(error)
        for i in range(0, min(len(message), 180), 40):
            screen.blit(font(16).render(message[i:i+40], True, MUTED), (20, 86+i//40*26))
        pg.display.flip()
        while True:
            if any(e.type == pg.QUIT for e in pg.event.get()):
                break
            await asyncio.sleep(0 if WEB else .05)
        pg.quit()
        return
    frame_clock = None if WEB else pg.time.Clock()
    while app.running:
        for event in pg.event.get():
            app.event(event)
        app.tick()
        app.draw()
        pg.display.flip()
        app.after_paint()
        if not WEB and os.environ.get("NANPURE_SMOKE_SNAPSHOT"):
            pg.image.save(app.screen, os.environ["NANPURE_SMOKE_SNAPSHOT"])
            app.running = False
        await asyncio.sleep(0)
        if frame_clock is not None:
            frame_clock.tick(60)
    if not WEB:
        app.saves.flush()
    pg.quit()
