"""Desktop entry point; pygbag runs the same async application."""
import asyncio
import pygame  # pygbag scans entry-point imports before loading compiled modules.
from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).resolve().parent/"src"))
from nanpure.app import main

if sys.platform == 'emscripten':
    asyncio.run(main())
elif __name__ == '__main__':
    import time
    coroutine = main()
    try:
        while True:
            coroutine.send(None)
            time.sleep(.016)
    except StopIteration:
        pass
